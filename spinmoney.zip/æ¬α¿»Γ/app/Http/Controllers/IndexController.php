<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Spinner;
use App\User;
use App\Drops;
use App\Operation;
use App\Http\Requests;
use Auth;
use DB;
use Carbon\Carbon;

class IndexController extends Controller
{
	const merchant_id = ''; //free-kassa
	const merchant_secret_1 = ''; //free-kassa
	const merchant_secret_2 = ''; //free-kassa
	const YT_CHANCE = 80;
    public function index(Request $r)
	{
		if(isset($r->ref))
		{
			$r->session()->put('ref', $r->ref);
		}
		$spinners = Spinner::get();
		$drops = Drops::orderBy('id', 'desc')->limit(12)->get();
		foreach($drops as $d)
		{
			$spinner = Spinner::where('id', $d->spinner_id)->first();
			$d->color = $spinner->color;
			$user = User::where('id', $d->user_id)->first();
			$d->avatar = $user->avatar;
		}
		$total = Drops::get()->count();
		$winners = User::orderBy('profit', 'desc')->limit(12)->get();
		foreach($winners as $w)
		{
			$w->total = Drops::where('user_id', $w->id)->count();
		}
		return view('pages.index', compact('spinners', 'drops', 'winners', 'total'));
	}
	public function spinner($id)
	{
		$spinner = Spinner::where('id', $id)->first();
		if($spinner == false)
		{
			abort('404');
		}
		else
		{
			$spinner->bonus = $spinner->max_profit + ($spinner->max_profit/100*3);
			$drops = Drops::orderBy('id', 'desc')->limit(12)->get();
			foreach($drops as $d)
			{
				$spinn = Spinner::where('id', $d->spinner_id)->first();
				$d->color = $spinn->color;
				$user = User::where('id', $d->user_id)->first();
				$d->avatar = $user->avatar;
			}
			$total = Drops::get()->count();
			return view('pages.spinner', compact('spinner', 'drops', 'total'));
		}
	}
	public function reviews()
	{
		$drops = Drops::orderBy('id', 'desc')->limit(12)->get();
		foreach($drops as $d)
		{
			$spinner = Spinner::where('id', $d->spinner_id)->first();
			$d->color = $spinner->color;
			$user = User::where('id', $d->user_id)->first();
			$d->avatar = $user->avatar;
		}
		$total = Drops::get()->count();
		return view('pages.reviews', compact('drops', 'total'));
	}
	public function help()
	{
		$drops = Drops::orderBy('id', 'desc')->limit(12)->get();
		foreach($drops as $d)
		{
			$spinner = Spinner::where('id', $d->spinner_id)->first();
			$d->color = $spinner->color;
			$user = User::where('id', $d->user_id)->first();
			$d->avatar = $user->avatar;
		}
		$total = Drops::get()->count();
		return view('pages.help', compact('drops', 'total'));
	}
	
	public function profile()
	{
		if(Auth::guest())
		{
			return redirect('/login');
		}
		else
		{
			$drops = Drops::orderBy('id', 'desc')->limit(12)->get();
			foreach($drops as $d)
			{
				$spinner = Spinner::where('id', $d->spinner_id)->first();
				$d->color = $spinner->color;
				$user = User::where('id', $d->user_id)->first();
				$d->avatar = $user->avatar;
			}
			$total = Drops::get()->count();
			$info = User::where('id', Auth::user()->id)->first();
			$info->total = Drops::where('user_id', $info->id)->count();
			$info->ref_count = User::where('ref_use', $info->ref_code)->count();
			
			
			$history = Drops::where('user_id', $info->id)->orderBy('id', 'desc')->limit(12)->get();
			foreach($history as $h)
			{
				$spinner = Spinner::where('id', $h->spinner_id)->first();
				$h->color = $spinner->color;
			}
			
			$refka = Operation::where('ref', Auth::user()->ref_code)->where('status', 1)->limit(12)->get();
			foreach($refka as $r)
			{
				$user = user::where('id', $r->user)->first();
				$r->username = $user->username;
				$r->date = Carbon::parse($r->created_at)->format('d.m.Y'); 
			}
			
			$operations = Operation::where('user', Auth::user()->id)->orderBy('id', 'desc')->limit(12)->get();
			foreach($operations as $o)
			{
				$o->date = Carbon::parse($o->created_at)->format('d.m.Y'); 
			}
			return view('pages.profile', compact('drops', 'info', 'history', 'refka' ,'operations' , 'total'));
		}
	}
	public function policy()
	{
		$drops = Drops::orderBy('id', 'desc')->limit(12)->get();
		foreach($drops as $d)
		{
			$spinner = Spinner::where('id', $d->spinner_id)->first();
			$d->color = $spinner->color;
			$user = User::where('id', $d->user_id)->first();
			$d->avatar = $user->avatar;
			$d->total = Drops::get()->count();
		}
		$total = Drops::get()->count();
		return view('pages.policy', compact('drops', 'total'));
	}
	public function user($id)
	{
		$drops = Drops::orderBy('id', 'desc')->limit(12)->get();
		foreach($drops as $d)
		{
			$spinner = Spinner::where('id', $d->spinner_id)->first();
			$d->color = $spinner->color;
			$user = User::where('id', $d->user_id)->first();
			$d->avatar = $user->avatar;
			$d->total = Drops::get()->count();
		}
		$total = Drops::get()->count();
		$user = User::where('id', $id)->first();
		if($user == false)
		{
			abort(404);
		}
		$user->referals = User::where('ref_use',$user->ref_code)->count();
		$user->spinners = Drops::where('user_id', $id)->count();
		$wins = Drops::where('user_id', $id)->orderBy('id', 'desc')->limit(12)->get();
		foreach($wins as $w)
		{
			$spinner = Spinner::where('id', $w->spinner_id)->first();
			$w->color = $spinner->color;
			
		}
		return view('pages.user', compact('drops', 'user', 'wins', 'total'));
	}
	/*api*/
	public function spin(Request $r)
	{
		$spinner = Spinner::where('id', $r->id)->first();
		if($spinner == false)
		{
			return response()->json(['success' => false, 
									 'error' => 'Спиннер не найден']);
		}
		if(Auth::guest())
		{
			return response()->json(['success' => false, 
									 'error' => 'Необходимо авторизоваться']);
		}
		if(Auth::user()->money < $spinner->price)
		{
			return response()->json(['success' => false, 
									 'error' => 'Недостаточно средств на балансе!']);
		}
		if(Auth::user()->is_yt == 0)
		{
			$chance = $spinner->chance;
		}
		else
		{
			$chance = self::YT_CHANCE;
		}
		$from = $r->rangeFrom;
		$to = $r->rangeTo;
		$pro = mt_rand(1, 100);
		
		if($pro >= $chance)
		{ // Шанс определился в проигрышную сторону
			if($from == 1)
			{
				$p = mt_rand($to, $spinner->max_spin);
				$spins_count = $p;
			}
			elseif($to == $spinner->max_spin)
			{
				$p = mt_rand(1, $from);
				$spins_count = $p;
			}
			else
			{
				$pp = mt_rand(1,100);
				if($pp <= 50)
				{
					$p = mt_rand(1, $from);
					$spins_count = $p;
				}
				else
				{
					$p = mt_rand($to, $spinner->max_spin);
					$spins_count = $p;
				}
			}
			
		}
		else
		{ // Шанс определился в выйгрышную сторону
			$spins_count = mt_rand($from, $to);
		}
		$user = User::where('id', Auth::user()->id)->first();
		$user->money = $user->money - $spinner->price;
		$user->save();
		if($spins_count >= $from && $spins_count <= $to)
		{
			$ratio = 0.6;
			$user->money = $user->money+$spinner->max_profit;
			$win_s = $spinner->max_profit;
			$user->save();
		}
		else
		{
			$ratio = 0.3;
			$win_s = mt_rand(1, $spinner->price/2);
			$user->money = $user->money+$win_s;
			$user->save();
		}
		//dd($win_s);
		Drops::create([
			'spinner_id' => $spinner->id,
			'user_id' => Auth::user()->id,
			'win' => $win_s
		]);
		$user->profit = $user->profit+$win_s;
		$user->save();
		
		return response()->json(['success' => true, 
								 'spinsCount' => $spins_count,
								 'ratio' => $ratio,
								 'balance' => $user->money, 
								 'winSum' => $win_s]);
	}
	
	
	public function last()
	{
		$drop = Drops::orderBy('id', 'desc')->first();
		$spinner = Spinner::where('id', $drop->spinner_id)->first();
		$user = User::where('id', $drop->user_id)->first();
		$total = Drops::get()->count();
		
		
		return response()->json(['newDrop' => "<a class='livedrop-item {$spinner->color}-spinner col-lg-1 js-livedrop-item' href='/user/{$drop->user_id}'><div class='livedrop-item-box'><img class='livedrop-img' src='/images/spinners/livedrop/{$spinner->color}-spinner.png' alt='Yellow Spinner'><img class='user-livedrop-avatar' src='{$user->avatar}' width='43'><div class='livedrop-win'><span class='livedrop-win-value'>{$drop->win} <span class='rouble'>&#8399;</span></span></div></div></a>",
		'totalOpens' => $total]);
	}
	
	
	public function refill(Request $r)
	{
		if(Auth::guest())
		{
			return response()->json(['success' => false, 
									 'error' => 'Нужно авторизоваться']);
		}
		else
		{
			if(!isset($r->walletId) && !isset($r->sum))
			{
				return response()->json(['success' => false, 
									 'error' => 'Заполните все поля']);
			}
			if($r->sum == 0)
			{
				return response()->json(['success' => false, 
									 'error' => 'Сумма не может быть равна нулю!']);
			}
			$wallet = $r->walletId;
			if($wallet == '')
			{
				$wallet = 0;
			}
			$amount = $r->sum;
			$ref = $amount/100*5;
			$int_id =  DB::table('operations')->insertGetId([
				'type' => 1,
				'amount' => (int)$amount,
				'user' => Auth::user()->id,
				'ref' => Auth::user()->ref_use,
				'ref_sum' => $ref,
				'time' => time(), 
				'status' => 0
			]);
			$orderID = $int_id;
			$sign = md5(self::merchant_id.':'.$amount.':'.self::merchant_secret_1.':'.$orderID);
			$url = 'http://www.free-kassa.ru/merchant/cash.php?m='.self::merchant_id.'&oa='.$amount.'&o='.$orderID.'&s='.$sign.'&lang=ru&i='.$wallet;
			return response()->json(['success' => true,
									'redirect' => $url]);
		}
	}
	
	function getIP() {
		if(isset($_SERVER['HTTP_X_REAL_IP'])) return $_SERVER['HTTP_X_REAL_IP'];
		return $_SERVER['REMOTE_ADDR'];
	}
	public function getPayment(Request $request)
	{
		if (!in_array($this->getIP(), array('136.243.38.147', '136.243.38.149', '136.243.38.150', '136.243.38.151', '136.243.38.189', '88.198.88.98'))) {
			return "IP not accepted";
		}
		$order = DB::table('operations')->where('id', $request->MERCHANT_ORDER_ID)->first();
		if(count($order) == 0)
		{
			return "Заказ не найден в базе данных";
		}
		else
		{
			if($order->status != 0)
			{
				return "Заказ уже был оплачен";
			}
			else
			{
				if($order->amount != $request->AMOUNT)
				{
					return "Сумма не совпадает";
				}
				else
				{
					$user = User::where('id', $order->user)->first();
					$user->money = $user->money + $request->AMOUNT;
					$user->save();
					$ruser = User::where('ref_code', $order->ref)->first();
					if($ruser == true)
					{
						$ruser->money = $ruser->money + $order->ref_sum;
						$ruser->save();
					}
					DB::table('operations')
							->where('id', $order->id)
							->update(['status' => 1]);
					return 'success';
				}
			}
		}
	}
	public function withdraw(Request $r)
	{
		if(!isset($r->walletId) || !isset($r->sum) || !isset($r->number))
		{
			return response()->json(['success' => false, 
									 'error' => 'Не переданы параметры']);
		}
		if(Auth::guest())
		{
			return response()->json(['success' => false, 
									 'error' => 'Необходимо авторизоваться']);
		}
		if(Auth::user()->money < $r->sum)
		{
			return response()->json(['success' => false, 
									 'error' => 'У Вас недостаточно денег']);
		}
		if($r->walletId == '' || $r->sum == '' || $r->number == '')
		{
			return response()->json(['success' => false, 
									 'error' => 'Заполните все необходимые поля']);
		}
		$ops = Operation::where('user', Auth::user()->id)->where('type', 2)->where('status', 0)->first();
		if($ops == true)
		{
			return response()->json(['success' => false, 
									 'error' => 'Дождитесь предыдущего вывода']);
		}
		else
		{
			$user = User::where('id', Auth::user()->id)->first();
			$user->money = $user->money - $r->sum;
			$user->save();
			$d = Operation::create([
				'type' => 2,
				'amount' => $r->sum,
				'user' => Auth::user()->id,
				'time' => time(),
				'status' => 0,
				'wallet' => $r->walletId,
				'number' => $r->number
			]);
			if($d == true)
			{
				return response()->json(['success' => true]);
			}
		}
	}
	public function windrop(Request $r)
	{
		if(!isset($r->userId))
		{
			$drops = Drops::where('user_id', Auth::user()->id)->orderBy('id', 'desc')->get();
			$html = '';
			foreach($drops as $d)
			{
				$spinner = Spinner::where('id', $d->spinner_id)->first();
				$html = $html."<a class='livedrop-item {$spinner->color}-spinner col-lg-1 js-livedrop-item' href='/spinner/{$d->spinner_id}'><div class='livedrop-item-box'><img class='livedrop-img' src='/images/spinners/livedrop/{$spinner->color}-spinner.png'><div class='livedrop-win'><span class='livedrop-win-value'>{$d->win} <span class='rouble'>&#8399;</span></span></div></div></a>";
			}
			return response()->json(['success' => true, 
									 'html' => $html]);
		}
		else
		{
			$drops = Drops::where('user_id', $r->userId)->orderBy('id', 'desc')->get();
			$html = '';
			foreach($drops as $d)
			{
				$spinner = Spinner::where('id', $d->spinner_id)->first();
				$html = $html."<a class='livedrop-item {$spinner->color}-spinner col-lg-1 js-livedrop-item' href='/spinner/{$d->spinner_id}'><div class='livedrop-item-box'><img class='livedrop-img' src='/images/spinners/livedrop/{$spinner->color}-spinner.png'><div class='livedrop-win'><span class='livedrop-win-value'>{$d->win} <span class='rouble'>&#8399;</span></span></div></div></a>";
			}
			return response()->json(['success' => true, 
									 'html' => $html]);
		}
	}
	public function operations()
	{
		if(Auth::guest())
		{
			abort('404');
		}
		else
		{
			$drops = Operation::where('user', Auth::user()->id)->orderBy('id', 'desc')->get();
			$html = '<tr>
						<td>№</td>
						<td>Тип операции</td>
						<td>Кошелек</td>
						<td>Сумма</td>
						<td>Статус</td>
						<td>Дата</td>
					</tr>';
			foreach($drops as $d)
			{
				$d->date = Carbon::parse($d->created_at)->format('d.m.Y'); 
				if($d->type == 1)
				{
					if($d->status == 1)
					{
						$status = '<span class="color-limegreen">Выполнена</span>';
					}
					else
					{
						$status = '';
					}
					$html = $html."<tr>
									<td>{$d->id}</td>
									<td>Пополнение кошелька</td>
									<td></td>
									<td style='text-align:right;font-weight:bold;'>{$d->amount} <span class='rouble'>₽</span></td>
									<td>
									{$status}
									</td>
									<td>{$d->date}</td>
								</tr>";
				}
				else
				{
					if($d->status == 1)
					{
						$status = '<span class="color-limegreen">Выполнена</span>';
					}
					else
					{
						$status = '<span class="color-primary">Ожидает</span>';
					}
					$html = $html."<tr>
									<td>{$d->id}</td>
									<td>Вывод</td>
									<td>{$d->number}</td>
									<td style='text-align:right;font-weight:bold;'>{$d->amount} <span class='rouble'>₽</span></td>
									<td>
									{$status}
									</td>
									<td>{$d->date}</td>
								</tr>";
				}
			}
			return response()->json(['success' => true, 
									 'html' => $html]);
		}
	}
	public function referals()
	{
		if(Auth::guest())
		{
			abort('404');
		}
		else
		{
			$refka = Operation::where('ref', Auth::user()->ref_code)->where('status', 1)->limit(12)->get();
			$html = '<tr>
						<td>№</td>
						<td>Пользователь</td>
						<td>Пополнение</td>
						<td>Вы получили</td>
						<td>Дата</td>
					</tr>';
			foreach($refka as $r)
			{
				$user = user::where('id', $r->user)->first();
				$r->username = $user->username;
				$r->date = Carbon::parse($r->created_at)->format('d.m.Y'); 
				$html = $html."<tr>
									<td>{$r->id}</td>
									<td>{$r->username}</td>
									<td>{$r->amount} <span class='rouble'>₽</span></td>
									<td>{$r->ref_sum} <span class='rouble'>₽</span></td>
									<td>{$r->date}</td>
								</tr>";
			}
			return response()->json(['success' => true, 
									 'html' => $html]);
		}
	}
	public function ws(Request $r)
	{
	}
}
