<?php namespace App\Http\Controllers;

use App\User;
use App\Spinner;
use App\Operation;
use Carbon\Carbon;
use Illuminate\Http\Request;

class AdminController extends Controller
{
	public function index()
    {
		$user_money = \DB::table('users')->where('money', '!=', 0)->sum('money');
		$user_today = \DB::table('users')->where('created_at', '>=', Carbon::today())->count();
		$opened_today = \DB::table('drops')->where('created_at', '>=', Carbon::today())->count();
		$pay_today = \DB::table('operations')->where('created_at', '>=', Carbon::today())->where('status', 1)->where('type', 1)->sum('amount');
		$pay_week = \DB::table('operations')->where('created_at', '>=', Carbon::now()->subDays(7))->where('type', 1)->where('status', 1)->sum('amount');
		$pay_month = \DB::table('operations')->where('created_at', '>=', Carbon::now()->subDays(30))->where('status', 1)->where('type', 1)->sum('amount');
		$pay_all = \DB::table('operations')->where('status', 1)->where('type', 1)->sum('amount');
		
		if(!$user_money) $user_money = 0;
		if(!$user_today) $user_today = 0;
		if(!$opened_today) $opened_today = 0;
		if(!$pay_today) $pay_today = 0;
		if(!$pay_week) $pay_week = 0;
		if(!$pay_month) $pay_month = 0;
		if(!$pay_all) $pay_all = 0;

		return view('admin.index', compact('user_money', 'user_today', 'opened_today', 'pay_today', 'pay_week', 'pay_month', 'pay_all')); 
    }
	
	public function users()
    {
		$users = User::get();
		return view('admin.pages.users', compact('users')); 
    }
	
	public function edit_user($id)
    {
		return view('admin.includes.modal_users', ['user' => User::findOrFail($id)]);
    }
	public function edit_withdraw($id)
	{
		
		$user = \DB::table('withdraw')->where('id', $id)->first();
		$user->user = User::where('id', $user->user_id)->first();
		return view('admin.includes.modal_withdrows', compact('user'));
	}
	public function withdraw_save(Request $r)
	{
		if($r->get('status') == 0 || $r->get('status') == 1)
		{
			Operation::where('id', $r->get('id'))->update([
				'status' => $r->get('status')
			]);
		}
		elseif($r->get('status') == 2)
		{
			$withdraw = Operation::where('id', $r->get('id'))->first();
			$user = User::where('id', $withdraw->user_id)->first();
			$user->money = $user->money + $withdraw->amount;
			$user->save();
			$withdraw->status = 2;
			$withdraw->save();
		}
		$r->session()->flash('alert-success', 'Статус выплаты обновлен!');
		return redirect()->back();
	}
	public function user_save(Request $r) 
	{     
        User::where('id', $r->get('id'))->update([
            'money' => $r->get('money'),
            'is_admin' => $r->get('is_admin'),
            'is_yt' => $r->get('is_yt')
        ]);
		
		$r->session()->flash('alert-success', 'Настройки пользователя сохранены!');
        return redirect()->route('users');
    }
	public function new_case()
    {
		return view('admin.pages.new_case'); 
    }
	
	public function case_edit($id)
    {
		$case = Spinner::where('id', $id)->first();
		
		return view('admin.pages.edit_case', compact('case'));
    }
	
	public function add_case(Request $r) {     
        Spinner::create([
			'name' => $r->get('name'),
            'price' => $r->get('price'),
            'image' => $r->get('image'),
            'color' => $r->get('color'),
            'diapasone' => $r->get('diapasone'),
            'max_spin' => $r->get('max_spin'),
            'max_profit' => $r->get('max_profit'),
			'chance' => $r->get('chance')
        ]);
		
		$r->session()->flash('alert-success', 'Вы создали новый кейс!');
        return redirect()->route('cases');
    }
	
	public function case_update(Request $r) {     
        Spinner::where('id', $r->get('id'))->update([
            'name' => $r->get('name'),
            'price' => $r->get('price'),
			'color' => $r->get('color'),
			'diapasone' => $r->get('diapasone'),
			'max_spin' => $r->get('max_spin'),
			'max_profit' => $r->get('max_profit'),
            'chance' => $r->get('chance')
        ]);
		
		$r->session()->flash('alert-success', 'Вы обновили кейс!');
        return redirect()->route('cases');
    }
	
	public function case_delete($id, Request $r) {
		Spinner::where('id', $id)->delete();
		
		$r->session()->flash('alert-success', 'Кейс удален!');
        return redirect()->route('cases');
	}
	
	public function cases() {
		$cases = Spinner::get();
		return view('admin.pages.cases', compact('cases')); 
    }

	
	public function withdraw()
    {
		$withdrows = Operation::where('type', 2)->where('status', 0)->orderBy('id', 'desc')->get();
		foreach($withdrows as $w)
		{
			$user = \DB::table('users')->where('id', $w->user)->first();
			$w->user = $user;
			$date = $w->created_at;
			$w->dfh = Carbon::createFromFormat('Y-m-d H:i:s', $date)->diffForHumans();
		}
		return view('admin.pages.withdraw', compact('withdrows')); 
    }
	
	public function payments()
	{
		$a = \DB::table('operations')->orderBy('id', 'desc')->where('status', 1)->where('type', 1)->take(20)->get();
		foreach ($a as $b) {
			$u = User::find($b->user);
			$b->name = $u->username;
			$b->name_id = $u->id;
		}
		return view('admin.pages.payments', compact('a'));
	}
	
	public function getBalans_frw() {
		$data = array(
			'wallet_id' => $this->config->fk_wallet,
			'sign' => md5($this->config->fk_wallet.$this->config->fk_api),
			'action' => 'get_balance',
		);
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, 'https://wallet.free-kassa.ru/api_v1.php');
		curl_setopt($ch, CURLOPT_HEADER, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_TIMEOUT, 10);
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		$result = curl_exec($ch);
		curl_close($ch);

		$json = json_decode($result, true);

		if(!$json['status']) return;

		return $json['data']['RUR'];
    } 
	public function generate()
    {
        $length = 15;
        $chars = 'abdefhiknrstyzABDEFGHKNQRSTYZ23456789';
        $numChars = strlen($chars);
        $string = '';
        for ($i = 0; $i < $length; $i++) {
            $string .= substr($chars, rand(1, $numChars) - 1, 1);
        }
        return $string;
    }
}