<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', 'IndexController@index');
Route::get('/spinner/{id}', 'IndexController@spinner');
Route::get('/user/{id}', 'IndexController@user');
Route::get('/reviews', 'IndexController@reviews');
Route::get('/help','IndexController@help');
Route::get('/profile', 'IndexController@profile');
Route::get('/policy', 'IndexController@policy');



Route::post('/api/spin', 'IndexController@spin');
Route::post('/api/last', 'IndexController@last');
Route::post('/api/refill', 'IndexController@refill');
Route::post('/api/withdraw', 'IndexController@withdraw');
Route::get('/getPayment', 'IndexController@getPayment');
Route::post('/api/profile/load/windrop','IndexController@windrop');
Route::post('/api/profile/load/referals','IndexController@referals');
Route::post('/api/profile/load/operations', 'IndexController@operations');


Route::get('/ws', 'IndexController@ws');


Route::get('/login', ['as' => 'login', 'uses' => 'LoginController@vklogin']);
Route::group(['middleware' => 'auth'], function () {
    Route::get('/logout', 'LoginController@logout');
});

Route::group(['middleware' => 'auth', 'middleware' => 'access:admin'], function () {
	Route::get('/admin', ['as' => 'admin', 'uses' => 'AdminController@index']);
	/* Players */
	Route::get('/admin/users', ['as' => 'users', 'uses' => 'AdminController@users']);
	Route::post('/admin/user/save', ['as' => 'user.save', 'uses' => 'AdminController@user_save']);
	Route::get('/admin/user/{id}/edit', ['as' => 'user.edit', 'uses' => 'AdminController@edit_user']);
	/* Cases */
	Route::get('/admin/cases', ['as' => 'cases', 'uses' => 'AdminController@cases']);
	Route::get('/admin/new_case', ['as' => 'new_case', 'uses' => 'AdminController@new_case']);
	Route::get('/admin/case/{id}/edit', ['as' => 'case.edit', 'uses' => 'AdminController@case_edit']);
	Route::get('/admin/case/{id}/delete', ['as' => 'case.delete', 'uses' => 'AdminController@case_delete']);
	Route::post('/admin/case/save', ['as' => 'case.save', 'uses' => 'AdminController@add_case']);
	Route::post('/admin/case/update', ['as' => 'case.upd', 'uses' => 'AdminController@case_update']);
	/* Withdraw */
	Route::get('/admin/withdraw', ['as' => 'withdraw', 'uses' => 'AdminController@withdraw']);
	Route::post('/admin/withdraw/save', ['as' => 'withdraw.save', 'uses' => 'AdminController@withdraw_save']);
	Route::get('/admin/withdraw/{id}/edit', ['as' => 'withdraw.edit', 'uses' => 'AdminController@edit_withdraw']);
	/*Payments*/
	Route::get('/admin/payments', 'AdminController@payments');
});
