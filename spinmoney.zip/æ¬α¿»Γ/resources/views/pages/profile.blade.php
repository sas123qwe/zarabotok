@extends('layout')

@section('content')
<div id="content">
	<div class="profile-page">
		<div class="container">
			<div class="row">
			<div class="col-lg-3 col-sm-3 col-md-3 col-12">
				<div class="profile-sidebar">
					<img src="{{$info->avatar}}" width="127px" height="127px">
					<p class="username">{{ $info->username }}</p>
					<p class="user-balance"><span class="color-primary">{{ $info->money }} <span class="rouble">₽</span> </span></p>
					<a onclick="$('#refillmodal').modal('show');" class="btn">Пополнить баланс</a>
					<a onclick="$('#withdrawmodal').modal('show');" class="btn">Вывести средства</a>
					<a href="/logout" class="btn logout">Выйти</a>
				</div>
			</div>
			<div class="col-lg-9 col-sm-9 col-md-9 col-12">
				<div class="profile-inner">
					<div class="profile-head">
						<div class="tabs-row">
							<div class="item">
								<div class="stat tltp">
									<i class="icon-spin-count"></i>
									<span class="value">{{ $info->total }}</span>
									<div class="tooltiptext">Открыто спиннеров</div>
								</div>
								<a href="#spins">История игр</a>
							</div>
							<div class="item">
								<div class="stat tltp">
									<i class="icon-partner"></i>
									<span class="value">{{ $info->ref_count }}</span>
									<div class="tooltiptext">Привлечено рефералов</div>
								</div>
								<a href="#partner">Партнерская программа</a>
							</div>
							<div class="item">
								<div class="stat tltp">
									<i class="icon-money"></i>
									<span class="value">{{ $info->profit }} <span class="rouble" style="margin-left:0;vertical-align: top;">₽</span></span>
									<div class="tooltiptext">Всего выиграно</div>
								</div>
								<a href="#finance">Финансы</a>
							</div>
						</div>
					</div>
					<div class="profile-content">
						<div class="container" id="spins">
							<div class="pageblocktitle">
								<span>История игр</span>
							</div>
							<div class="pageinner">
								<div class="wins-list js-wins row">
								@foreach($history as $h)
									<a class="livedrop-item {{$h->color}}-spinner col-lg-1 js-livedrop-item" href="/spinner/{{$h->spinner_id}}">
										<div class="livedrop-item-box">
											<img class="livedrop-img" src="/images/spinners/livedrop/{{$h->color}}-spinner.png">
											<div class="livedrop-win">
												<span class="livedrop-win-value">{{$h->win}} <span class="rouble">₽</span></span>
											</div>
										</div>
									</a>			
								@endforeach
								</div>
								<div class="text-center">
									<button class="js-load-wins btn">Показать еще</button>
								</div>
							</div>
						</div>

						<div class="container" id="partner">
							<div class="pageblocktitle">
								<span>Партнерская программа</span>
							</div>
							<div class="pageinner">
								<div class="partner-box">
									<h3>Приглашай друзей и зарабатывай <span class="text-bold color-primary">5%</span> от их пополнений!</h3>
									<div class="desc">
										<p>1. Вы отправляете свою уникальную ссылку друзьям.</p>
										<p>2. Ваш друг переходит по ссылке на наш сайт, авторизуется и получает бонусные <span class="color-primary">40 рублей</span> на баланс!</p>
										<p>3. За каждое пополнение баланса вашим другом вы получаете <span class="color-primary">5%</span> от суммы его пополнения!</p>
										<p>Например: если ваш друг пополнит свой баланс на 1000 рублей - мы начислим <span class="color-primary">50 рублей</span> на ваш счет!</p>
									</div>
									<div class="partner-link-box container-fluid">
										<p>Твоя партнерская ссылка:</p>
										<input type="text" value="https://spinmoney.online?ref={{$info->ref_code}}" id="partner-link-input">
										<button class="btn partner-copy">Скопировать</button>
									</div>
								</div>
							</div>
							<div class="pageinner" style="margin-top:30px;">
								<table>
									<tbody class="js-referals">
										<tr>
											<td>№</td>
											<td>Пользователь</td>
											<td>Пополнение</td>
											<td>Вы получили</td>
											<td>Дата</td>
										</tr>
										@foreach($refka as $r)
										<tr>
											<td>{{$r->id}}</td>
											<td>{{$r->username}}</td>
											<td>{{$r->amount}} <span class="rouble">₽</span></td>
											<td>{{$r->ref_sum}} <span class="rouble">₽</span></td>
											<td>{{$r->date}}</td>
										</tr>
										@endforeach
									</tbody>
								</table>
								<div class="text-center">
									<button class="js-load-referals btn  hidden">Показать еще</button>
								</div>
							</div>
						</div>

						<div class="container" id="finance">
							<div class="pageblocktitle">
								<span>Финансовые операции</span>
							</div>
							<div class="pageinner">
								<table>
									<tbody class="js-operations">
										<tr>
											<td>№</td>
											<td>Тип операции</td>
											<td>Кошелек</td>
											<td>Сумма</td>
											<td>Статус</td>
											<td>Дата</td>
										</tr>
										@foreach($operations as $o)
											<tr>
												<td>{{$o->id}}</td>
												<td>@if($o->type == 1) Пополнение кошелька @else Вывод @endif</td>
												<td>@if($o->type == 2) {{ $o->number }} @else @endif</td>
												<td style="text-align:right;font-weight:bold;">{{$o->amount}} <span class="rouble">₽</span></td>
												<td>
													@if($o->status == 1)
													<span class="color-limegreen">Выполнена</span>
													@elseif($o->status == 0 && $o->type == 2)
													<span class="color-primary">Ожидает</span>
													@endif
												</td>
												<td>{{$o->date}}</td>
											</tr>
										@endforeach
									</tbody>
								</table>
								<div class="text-center">
									<button class="js-load-operations btn">Показать еще</button>
								</div>
								<br>
							</div>
						</div>

					</div>
				</div>
			</div>
			</div>
		</div>
	</div>
		</div>
@stop


@section('scripts')
<script src="/js/ProfileModule.js"></script>
<script>
$(document).ready(function() {

	$('.partner-copy').on('click', function(){
		copyToClipboard($('#partner-link-input').attr('value'));
		return false;
	});

	$('#partner-link-input').on('click', function(){
		$(this).select();
	});

	function copyToClipboard(link) {
	  $("body").append('<input id="link" value="'+link+'">');
	  $('input#link').select();
	  document.execCommand("copy");
	  Utils.showMessage("Текст скопирован в буфер обмена")
	  $('input#link').remove();
	  return false;
	}
});
</script>
<script>
	ProfileModule.init({
		"blockWins":".js-wins",
		"buttonLoadWins":".js-load-wins",
		"blockWinsPage":1,
		"csrf":"{{ csrf_token() }}",
		"blockOperations":".js-operations",
		"buttonLoadOperations":".js-load-operations",
		"blockOperationsPage":1,
		"blockReferals" : ".js-referals",
		"buttonLoadReferals" : ".js-load-referals",
		"blockReferalsPage":1
	});
</script>
@stop