@extends('layout')

@section('content')
<div class="container">
		<br>
		<div id="vk_comments"></div>
		<script type="text/javascript">
		VK.Widgets.Comments("vk_comments", {limit: 20, attach: "*"});
		</script>
		<br>
	</div>
@stop