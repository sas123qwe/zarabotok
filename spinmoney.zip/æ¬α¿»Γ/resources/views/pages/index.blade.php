@extends('layout')

@section('content')
		<div id="content">
		<div class="container">
		<div class="row justify-content-between">
			@if(isset($spinners))
				@foreach($spinners as $s)
				<div class="col-lg-3 col-sm-6 col-md-6 col-xs-12">
					<div class="spinner {{$s->color}}-spinner">
						<a href="/spinner/{{$s->id}}">
							<div class="row">
								<div class="col-lg-6 text-left col-6">
									<span class="spinscount">
									{{ $s->max_spin }}
									</span>
								</div>
								<div class="col-lg-6 text-right col-6">
									<span class="price"><span class="font-bold">{{ $s->price }}</span> <span class="rouble">&#8399;</span></span>
								</div>
							</div>
							<div class="image">
								<img src="{{$s->image}}" alt="{{$s->name}}">
							</div>
							<div class="name">{{$s->name}}</div>
							<div class="open">Открыть</div>
							<span class="openscount">
								Возможный выигрыш: <span class="font-bold color-primary">{{$s->max_profit}} <span class="rouble">&#8399;</span></span>
							</span>
						</a>
					</div>
				</div>
				@endforeach
			@endif
							
		</div>
	</div>
	<div id="winnerstop">
		<div class="container text-center">
			<div class="pageblocktitle">
				<span>Топ победителей</span>
			</div>
			<div class="text-left">
					@php
					$i = 1;
					@endphp
					@foreach($winners as $w)
					<div class="winner">
						<a class="row" href="/user/{{$w->id}}">
							<div class="col-lg-8 col-sm-8 col-4">
								<span class="place">{{$i}}</span>
								<img class="avatar" src="{{$w->avatar}}" alt="{{$w->username}}">
								<span class="name">{{$w->username}}</span>
							</div>
							<div class="col-lg-4 col-sm-4 col-8 text-right">
								<span class="spinscount">{{$w->total}}</span>
								<span class="color-primary moneywon font-light"><span class="font-bold">{{$w->profit}}</span> <span class="rouble">&#8399;</span></span>
							</div>
						</a>
					</div>
					@php
					$i++;
					@endphp
					@endforeach
					
			</div>
		</div>
	</div>
	<div id="features">
		<div class="container text-center">
			<div class="pageblocktitle">
				<span>Наши преимущества</span>
			</div>
			<div class="text-left row">
				<div class="col-lg-3 feature">
					<div class="icon icon-original"></div>
					<div class="name">Оригинальность</div>
					<div class="description">Мы единственные, кто связал трендовую вещь с интересным функционалом!</div>
				</div>
				<div class="col-lg-3 feature">
					<div class="icon icon-fast"></div>
					<div class="name">Быстрые выплаты</div>
					<div class="description">Мы гарантируем каждую выплату без комиссии. Минимальное время - 1 минута. В некоторых случаях придется подождать, но не более 24 часов!</div>
				</div>
				<div class="col-lg-3 feature">
					<div class="icon icon-safe"></div>
					<div class="name">Безопасность</div>
					<div class="description">Мы не имеем доступа к вашим аккаунтам в социальных сетях и не публикуем конфиденциальную информацию</div>
				</div>
				<div class="col-lg-3 feature">
					<div class="icon icon-clear"></div>
					<div class="name">Прозрачность</div>
					<div class="description">Мы подробно рассказываем о работе системы и показываем каждый выигрыш!</div>
				</div>
			</div>
		</div>
		</div>
	</div>
@stop
