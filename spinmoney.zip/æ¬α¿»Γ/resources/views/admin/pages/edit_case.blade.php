@extends('admin')

@section('content')
<div class="page-bar">
	<ul class="page-breadcrumb">
		<li>
			<a href="/admin">Главная</a>
			<i class="fa fa-circle"></i>
		</li>
		<li>
			<span>Редактировать спиннер</span>
		</li>
	</ul>
</div>

<h1 class="page-title"> Редактирование спиннера </h1>

<div class="flash-message">
    @foreach (['danger', 'warning', 'success', 'info'] as $msg)
      @if(Session::has('alert-' . $msg))

      <p class="alert alert-{{ $msg }}">{{ Session::get('alert-' . $msg) }} <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
      @endif
    @endforeach
</div> <!-- end .flash-message -->

<div class="row">
	<div class="col-md-12">
		<div class="portlet light bordered">
			<div class="portlet-body">
				<form method="post" action="/admin/case/update" class="horizontal-form" id="save">
					<input name="id" value="{{$case->id}}" type="hidden">
					<input type="hidden" name="_token" value="{{ csrf_token() }}">
					<div class="form-body">
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label class="control-label"><b>Название</b></label>
									<input type="text" class="form-control" placeholder="Название спинера" name="name" value="{{ $case->name }}">
								</div>
							</div>
							<!--/span-->
							<div class="col-md-6">
								<div class="form-group">
									<label class="control-label"><b>Цена</b></label>
									<input type="text" class="form-control" placeholder="0" name="price" value="{{ $case->price }}">
								</div>
							</div>
							<!--/span-->
						</div>
						<!--/row-->
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label class="control-label"><b>Цвет</b></label>
									<input type="text" class="form-control" placeholder="Цвет спиннера" name="color" value="{{ $case->color }}">
								</div>
							</div>
							<!--/span-->
							<div class="col-md-6">
								<div class="form-group">
									<label class="control-label"><b>Диапазон</b></label>
									<input type="text" class="form-control" placeholder="10" name="diapasone" value="{{ $case->diapasone }}">
								</div>
							</div>
							<!--/span-->
						</div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label class="control-label"><b>Максимальное число оборотов</b></label>
									<input type="text" class="form-control" placeholder="Максимальное число оборотов" name="max_spin" value="{{ $case->max_spin }}">
								</div>
							</div>
							<!--/span-->
							<div class="col-md-6">
								<div class="form-group">
									<label class="control-label"><b>Максимальный профит</b></label>
									<input type="text" class="form-control" placeholder="Максимальный выйгрыш" name="max_profit" value="{{ $case->max_profit }}">
								</div>
							</div>
							<!--/span-->
						</div>
						<div class="row" style="margin-top: 10px;">
							<div class="col-md-12">
								<div class="form-group text-center">
									<label class="control-label"><b>Картинка</b></label>
									<div class="col-md-12">
										<input type="text" class="form-control" placeholder="Путь к картинке" name="image" value="{{ $case->image }}">
										<img src="{{ $case->image }}" width="100px">
									</div>
								</div>
							</div>
						</div>
						<div class="row" style="margin-top: 10px;
												margin-bottom: 10px;">
							<div class="col-md-12">
								<div class="form-group">
									<label class="col-md-12 control-label text-center"><b>Шанс окупаемости</b></label>
									<div class="col-md-12">
										<input id="range_1" type="text" name="chance" value="{{ $case->chance }}"/>
									</div>
								</div>
							</div>
						</div>
					</div>
					
					<div class="form-actions right">
						<button type="submit" class="btn blue"><i class="fa fa-check"></i> Сохранить </button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
@endsection