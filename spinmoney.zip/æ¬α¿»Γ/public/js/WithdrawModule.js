var WithdrawModule = (function() {
	var _modal;
	var _modal_success;
	var _walletId;
	var _buttonWithdraw;
	var _buttonWallet;
	var _inputSum;
	var _inputNumber;
	var _csrf;

	var _init = function(params) {
		_modal = $(params["modal"]);
		_modal_success = $(params["modal_success"]);
		_buttonWallet = $(params["buttonWallet"]);
		_buttonWithdraw = $(params["buttonWithdraw"]);
		_inputSum = $(params["inputSum"]);
		_inputNumber = $(params["inputNumber"]);
		_csrf = params["csrf"];

		_setEvents();
	};
	var _setEvents = function() {
		_buttonWallet.on("click", _onButtonWalletClicked);
		_buttonWithdraw.on("click", _onButtonWithdrawClicked);
	};
	var _onButtonWithdrawClicked = function() {
		var formData = new FormData();
		formData.append("walletId", _walletId);
		formData.append("sum", $(_inputSum).val());
		formData.append("number", $(_inputNumber).val());
		formData.append("_token", _csrf);
		Utils.api("withdraw", formData, _withdrawSuccess, _withdrawError);
	};
	var _onButtonWalletClicked = function() {
		_walletId = $(event.target).data("currency-id");
		switch(_walletId) {
			case 94:
				_inputNumber.attr("placeholder", "1234 1234 1234 1234");
				break;
			case 106:
				_inputNumber.attr("placeholder", "WM123456789");
				break;
			case 63:
				_inputNumber.attr("placeholder", "+71231231212");
				break;
			case 1:
				_inputNumber.attr("placeholder", "R123456789123");
				break;
			case 45:
				_inputNumber.attr("placeholder", "123412341234123");
				break;
		}
		_buttonWallet.removeClass("active");
		$(event.target).addClass("active");
	};
	var _withdrawSuccess = function(response) {
		_modal.modal("toggle");
		_modal_success.modal("toggle");
	};
	var _withdrawError = function(response) {
		Utils.showError(response.error);
	};
	return {
		"init":_init
	}
})();