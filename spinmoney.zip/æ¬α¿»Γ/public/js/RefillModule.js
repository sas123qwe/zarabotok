var RefillModule = (function() {
	var _walletId;
	var _buttonRefill;
	var _buttonWallet;
	var _inputSum;
	var _csrf;

	var _init = function(params) {
		_buttonWallet = $(params["buttonWallet"]);
		_buttonRefill = $(params["buttonRefill"]);
		_inputSum = $(params["inputSum"]);
		_csrf = params["csrf"];

		_setEvents();
	};
	var _setEvents = function() {
		_buttonWallet.on("click", _onButtonWalletClicked);
		_buttonRefill.on("click", _onButtonRefillClicked);
	};
	var _onButtonWalletClicked = function(event) {
		_walletId = $(event.target).data("currency-id");
		_buttonWallet.removeClass("active");
		$(event.target).addClass("active");
	};
	var _onButtonRefillClicked = function(event) {
		var formData = new FormData();
		formData.append("walletId", _walletId);
		formData.append("sum", $(_inputSum).val());
		formData.append("_token", _csrf);
		Utils.api("refill", formData, _redirectToRefill, _refillError);
	};
	var _redirectToRefill = function(response) {
		document.location.href = response.redirect;
	};
	var _refillError = function(response) {
		Utils.showError(response.error);
	};
	return {
		init:_init
	}
})();