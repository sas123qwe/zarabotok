
var SocketModule = (function() {
	var _connection;
	var _connect = function(url) {
		_connection = io.connect(url);
	};
	var _setListener = function(event, callback) {
		_connection.on(event, callback);
	};
	return {
		"connect":_connect,
		"setListener":_setListener
	}
})();