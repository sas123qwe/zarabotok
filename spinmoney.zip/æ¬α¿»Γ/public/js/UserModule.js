var UserModule = (function() {
	var _blockWins;
	var _buttonLoadWins;
	var _csrf;
	var _userId;
	var _blockWinsPage;

	var _init = function(params) {
		_blockWins = $(params["blockWins"]);
		_buttonLoadWins = $(params["buttonLoadWins"]);
		_blockWinsPage = params["blockWinsPage"];
		_userId = params["userId"];
		_csrf = params["csrf"];

		_setEvents();
	};
	var _setEvents = function() {
		_buttonLoadWins.on("click", _buttonLoadWinsClicked);
	};
	var _buttonLoadWinsClicked = function() {
		var formData = new FormData();
		formData.append("_token", _csrf);
		formData.append("blockWinsPage", _blockWinsPage);
		formData.append("userId", _userId);
		Utils.api("profile/load/windrop", formData, _loadWinsSuccess, _loadWinsError);
	};
	var _loadWinsSuccess = function(response) {
		_blockWinsPage++;
		_blockWins.empty();
		_blockWins.append(response.html);
	};
	var _loadWinsError = function(response) {
		Utils.showError(response.error);
	};
	return {
		init:_init
	}
})();