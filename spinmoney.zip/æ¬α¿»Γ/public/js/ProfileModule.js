var ProfileModule = (function() {
	var _blockWins;
	var _buttonLoadWins;
	var _blockWinsPage;

	var _blockOperations;
	var _buttonLoadOperations;
	var _blockOperationsPage;

	var _csrf;

	var _init = function(params) {
		_blockWins = $(params["blockWins"]);
		_buttonLoadWins = $(params["buttonLoadWins"]);
		_blockWinsPage = params["blockWinsPage"];

		_blockOperations = $(params["blockOperations"]);
		_buttonLoadOperations = $(params["buttonLoadOperations"]);
		_blockOperationsPage = params["blockOperationsPage"];

		_blockReferals = $(params["blockReferals"]);
		_buttonLoadReferals = $(params["buttonLoadReferals"]);
		_blockReferalsPage = params["blockReferalsPage"];
		_csrf = params["csrf"];

		_setEvents();
	};
	var _setEvents = function() {
		_buttonLoadWins.on("click", _buttonLoadWinsClicked);
		_buttonLoadOperations.on("click", _buttonLoadOperationsClicked);
		_buttonLoadReferals.on("click", _buttonLoadReferalsClicked);
	};
	var _buttonLoadWinsClicked = function() {
		var formData = new FormData();
		formData.append("_token", _csrf);
		formData.append("blockWinsPage", _blockWinsPage);
		Utils.api("profile/load/windrop", formData, _loadWinsSuccess, _loadWinsError);
	};
	var _loadWinsSuccess = function(response) {
		_blockWinsPage++;
		_blockWins.empty();
		_blockWins.append(response.html);
		_buttonLoadWins.remove();
		if(!response.html) {
			_buttonLoadWins.remove();
		}
	};
	var _loadWinsError = function(response) {
		Utils.showError(response.error);
	};
	var _buttonLoadOperationsClicked = function() {
		var formData = new FormData();
		formData.append("_token", _csrf);
		formData.append("blockOperationsPage", _blockOperationsPage);
		Utils.api("profile/load/operations", formData, _loadOperationsSuccess, _loadOperationsError);
	};
	var _loadOperationsSuccess = function(response) {
		_blockOperationsPage++;
		_blockOperations.empty();
		_buttonLoadOperations.remove();
		_blockOperations.append(response.html);
		if(!response.html) {
			_buttonLoadOperations.remove();
		}
	};
	var _loadOperationsError = function(response) {
		Utils.showError(response.error);
	};
	var _buttonLoadReferalsClicked = function() {
		console.log("here");
		var formData = new FormData();
		formData.append("_token", _csrf);
		formData.append("blockReferalsPage", _blockReferalsPage);
		Utils.api("profile/load/referals", formData, _loadReferalsSuccess, _loadReferalsError);
	};
	var _loadReferalsSuccess = function(response) {
		_blockReferalsPage++;
		_blockReferals.empty();
		_blockReferals.append(response.html);
		_buttonLoadReferals.remove();
		if(!response.html) {
			_buttonLoadReferals.remove();
		}
	};
	var _loadReferalsError = function(response) {
		Utils.showError(response.error);
	}
	return {
		init:_init
	}
})();
