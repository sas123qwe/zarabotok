var scribe = require('scribe-js')(),
    app = require('express')(),
    server = require('http').Server(app),
    io = require('socket.io')(server),
    requestify = require('requestify');
var schedule = require('node-schedule');
server.listen(2019);

io.sockets.on('connection', function (socket) {
	console.log('Connected');
	socket.on('update', function(){
		console.log("update");
		requestify.post('http://localhost/api/last', {})
        .then(function (response) {
            data = response.body;
            io.sockets.emit('livedrop', data);
            console.log("livedrop");
        }, function (err) {

        });
	});

});
function updateOnline(){
    console.info('Connected ' + Object.keys(io.sockets.adapter.rooms).length + ' clients');
}
function updateStatus() {
    requestify.post('http://213.159.209.109/api/stats', {})
        .then(function (response) {
            data = JSON.parse(response.body);
            var online = Object.keys(io.sockets.adapter.rooms).length;
            var users = data.users;
            var tickets = data.tickets;
            var paid = data.paid;
            var data = [online, users, tickets, paid];
            io.sockets.emit('statbox', data);
            console.log("stats");
        }, function (err) {

        });
}
hour();
function hour() {
    schedule.scheduleJob('0 00 * * * *', function(){
        requestify.post('http://213.159.209.109/hour', {})
            .then(function (response) {
                console.log("HOur bonus");
            }, function (err) {

            });
    });

}
getCont();
function getCont() {
    schedule.scheduleJob('0 01 * * * *', function(){
        requestify.post('http://213.159.209.109/getContestants', {})
            .then(function (response) {
                console.log("Contestants check");
            }, function (err) {

            });
    });

}
function gifts() {
    setTimeout(function () {
        requestify.post('http://213.159.209.109/api/last', {})
            .then(function (response) {
                data = JSON.parse(response.body);
                io.sockets.emit('last games', data);

                console.log("last gifts");
            }, function (err) {

            });
    }, 1000);
}

io.sockets.on('last gift set', function () {
    setTimeout(function () {
        requestify.post('http://213.159.209.109/api/last_drop_get', {})
            .then(function (response) {
                data = JSON.parse(response.body);
                console.log("last gift set");
                io.sockets.emit('last gift get', data.last_drop);
            }, function (err) {

            });
    }, 4000);
})
