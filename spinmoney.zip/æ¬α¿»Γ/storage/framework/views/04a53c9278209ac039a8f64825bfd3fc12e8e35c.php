<?php $__env->startSection('content'); ?>
<div class="page-bar">
	<ul class="page-breadcrumb">
		<li>
			<a href="/admin">Главная</a>
			<i class="fa fa-circle"></i>
		</li>
		<li>
			<span>Пользователи</span>
		</li>
	</ul>
</div>

<h1 class="page-title"> Пользователи </h1>
<div class="flash-message">
    <?php foreach(['danger', 'warning', 'success', 'info'] as $msg): ?>
      <?php if(Session::has('alert-' . $msg)): ?>

      <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
      <?php endif; ?>
    <?php endforeach; ?>
</div> <!-- end .flash-message -->
<div class="row">
	<div class="col-md-12">
		<div class="portlet light bordered">
			<div class="portlet-body">
				<table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
					<thead>
						<tr>
							<th>ID</th>
							<th>Аватар</th>
							<th>Имя Фамилия</th>
							<th>Ссылка</th>
							<th>Баланс</th>
							<th>Управление</th>
						</tr>
					</thead>
					<tbody>
						<?php foreach($users as $user): ?>
						<tr>
							<td style="vertical-align: middle;"><?php echo e($user->id); ?></td>
							<td align="center"><img width="50px" src="<?php echo e($user->avatar); ?>"/></td>
							<td style="vertical-align: middle;"><?php echo e($user->username); ?></td>
							<td style="vertical-align: middle;"><a href="https://vk.com/id<?php echo e($user->login2); ?>" target="_blank">https://vk.com/id<?php echo e($user->login2); ?></a></td>
							<td style="vertical-align: middle;"><?php echo e($user->money); ?></td>
							<td align="center" style="vertical-align: middle;">
								<button type="button" class="btn blue btn-sm" data-toggle="modal" data-target="#usr_edit" href="/admin/user/<?php echo e($user->id); ?>/edit">Редактировать</button>
							</td>
						</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>

<div class="modal fade" id="usr_edit" tabindex="-1" role="basic" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<?php echo $__env->make('admin.includes.modal_users', ['user' => $user], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>