<!DOCTYPE html>
<html lang="ru">
	<head>
		<title>SpinMoney – крути и угадывай, открывай кейсы с деньгами и выигрывай</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="yandex-verification" content="54ed8458eb078834" />
		<meta name="description" content="Открывай кейсы с деньгами и выигрывай деньги" />
		<meta name="keywords" content="открытие кейсов,кейсы с деньгами,кейсы,спиннер" />
		<link rel="shortcut icon" href="/images/favicon.ico?v=2" type="image/x-icon">
		<link rel="icon" href="/images/favicon.ico?v=2" type="image/x-icon">

		<link href="/css/bootstrap.min.css" rel="stylesheet" type="text/css">
		<link href="/css/font-awesome.min.css" rel="stylesheet" type="text/css">
		<link href="/css/nouislider.css" rel="stylesheet" type="text/css">
		<link href="/css/layout.css?1503228428" rel="stylesheet" type="text/css">
		<link href="/css/adaptive.css?1503228428" rel="stylesheet" type="text/css">
		
	</head>
	<body>
<!-- Yandex.Metrika counter -->
<script type="text/javascript" >
    (function (d, w, c) {
        (w[c] = w[c] || []).push(function() {
            try {
                w.yaCounter45461952 = new Ya.Metrika({
                    id:45461952,
                    clickmap:true,
                    trackLinks:true,
                    accurateTrackBounce:true,
                    webvisor:true
                });
            } catch(e) { }
        });

        var n = d.getElementsByTagName("script")[0],
            s = d.createElement("script"),
            f = function () { n.parentNode.insertBefore(s, n); };
        s.type = "text/javascript";
        s.async = true;
        s.src = "https://mc.yandex.ru/metrika/watch.js";

        if (w.opera == "[object Opera]") {
            d.addEventListener("DOMContentLoaded", f, false);
        } else { f(); }
    })(document, window, "yandex_metrika_callbacks");
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/45461952" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->

		<div class="globalheader">
			<div class="container">
				<div class="row">
					<div class="col-lg-3 col-md-3 col-sm-4 col-4">
						<a href="/"><img id="logo" src="/images/logo.png" alt="SpinMoney"></a>
					</div>
					<div class="menu col-lg-7 col-md-7 col-sm-4 col-4 text-center">
						<button class="menu-btn btn" style="margin-top: 0;display:none;">Меню</button>
						<div class="menu-list">
						<a href="/help">Помощь</a>
						<a href="/reviews">Отзывы</a>
						<a href="/profile#partner">Партнерская программа</a>
						<?php if(!Auth::guest()): ?>
						<a onclick="$('#withdrawmodal').modal('show');">Вывод средств</a>
						<?php endif; ?>
					</div>
					</div>
					<div class="profile col-lg-2 col-md-2 col-sm-4 col-4">
							<?php if(Auth::guest()): ?>
							<div class="row nonautorized pull-right">
								<span>Войти через:</span>
								<a href="/login"><i class="fa fa-vk fa-2x"></i></a>
							</div>
							<?php else: ?>
							<div class="row autorized">
								<div class="col-lg-10 col-sm-9 col-9 text-right">
									<div class="profile-box">
										<a class="link" href="/profile">Мой профиль</a>
										<div>
											<a onclick="$('#refillmodal').modal('show');" class="add-funds">
												<span class="color-primary font-bold"><span class="js-balance"><?php echo e(Auth::user()->money); ?></span> <span class="rouble">⃏</span> </span> 
												<i class="icon-add-founds"></i>
											</a>
										</div>
									</div>
								</div>
								<a class="col-lg-2 col-sm-3 col-3 text-right" href="/profile">
									<img src="<?php echo e(Auth::user()->avatar); ?>" alt="<?php echo e(Auth::user()->username); ?>">
								</a>
							</div>
							<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
		<div id="livedrop">
			<div class="container">
				<span class="live-span" style="">LIVE</span>
				<span class="vk-btn" style=""><a target="_blank" href="https://vk.com/spinmoneyonline" style="
				    color: #fff;
				    font-size: 13px;
				    /* display: none; */
				"><img src="http://piterpen35.ru/images/vk.png" style="
				    width: 80px;
				">
				</a></span>
				<div class="row js-livedrop">
					<a class="livedrop-item yellow-spinner col-lg-1 js-livedrop-item" href="/user/428927784">
						<div class="livedrop-item-box">
							<img class="livedrop-img" src="/images/spinners/livedrop/yellow-spinner.png" alt="Yellow Spinner">
							<img class="user-livedrop-avatar" src="https://pp.userapi.com/c840024/v840024102/126de/duHQ8saUzHw.jpg" width="43">
							<div class="livedrop-win">
								<span class="livedrop-win-value">28 <span class="rouble">&#8399;</span></span>
							</div>
						</div>
					</a>											<a class="livedrop-item yellow-spinner col-lg-1 js-livedrop-item" href="/user/428927784">
						<div class="livedrop-item-box">
							<img class="livedrop-img" src="/images/spinners/livedrop/yellow-spinner.png" alt="Yellow Spinner">
							<img class="user-livedrop-avatar" src="https://pp.userapi.com/c840024/v840024102/126de/duHQ8saUzHw.jpg" width="43">
							<div class="livedrop-win">
								<span class="livedrop-win-value">138 <span class="rouble">&#8399;</span></span>
							</div>
						</div>
					</a>											<a class="livedrop-item yellow-spinner col-lg-1 js-livedrop-item" href="/user/428927784">
						<div class="livedrop-item-box">
							<img class="livedrop-img" src="/images/spinners/livedrop/yellow-spinner.png" alt="Yellow Spinner">
							<img class="user-livedrop-avatar" src="https://pp.userapi.com/c840024/v840024102/126de/duHQ8saUzHw.jpg" width="43">
							<div class="livedrop-win">
								<span class="livedrop-win-value">138 <span class="rouble">&#8399;</span></span>
							</div>
						</div>
					</a>											<a class="livedrop-item blue-spinner col-lg-1 js-livedrop-item" href="/user/428927784">
						<div class="livedrop-item-box">
							<img class="livedrop-img" src="/images/spinners/livedrop/blue-spinner.png" alt="Blue Spinner">
							<img class="user-livedrop-avatar" src="https://pp.userapi.com/c840024/v840024102/126de/duHQ8saUzHw.jpg" width="43">
							<div class="livedrop-win">
								<span class="livedrop-win-value">209 <span class="rouble">&#8399;</span></span>
							</div>
						</div>
					</a>											<a class="livedrop-item green-spinner col-lg-1 js-livedrop-item" href="/user/428927784">
						<div class="livedrop-item-box">
							<img class="livedrop-img" src="/images/spinners/livedrop/green-spinner.png" alt="Green Spinner">
							<img class="user-livedrop-avatar" src="https://pp.userapi.com/c840024/v840024102/126de/duHQ8saUzHw.jpg" width="43">
							<div class="livedrop-win">
								<span class="livedrop-win-value">80 <span class="rouble">&#8399;</span></span>
							</div>
						</div>
					</a>											<a class="livedrop-item green-spinner col-lg-1 js-livedrop-item" href="/user/428927784">
						<div class="livedrop-item-box">
							<img class="livedrop-img" src="/images/spinners/livedrop/green-spinner.png" alt="Green Spinner">
							<img class="user-livedrop-avatar" src="https://pp.userapi.com/c840024/v840024102/126de/duHQ8saUzHw.jpg" width="43">
							<div class="livedrop-win">
								<span class="livedrop-win-value">80 <span class="rouble">&#8399;</span></span>
							</div>
						</div>
					</a>											<a class="livedrop-item green-spinner col-lg-1 js-livedrop-item" href="/user/428927784">
						<div class="livedrop-item-box">
							<img class="livedrop-img" src="/images/spinners/livedrop/green-spinner.png" alt="Green Spinner">
							<img class="user-livedrop-avatar" src="https://pp.userapi.com/c840024/v840024102/126de/duHQ8saUzHw.jpg" width="43">
							<div class="livedrop-win">
								<span class="livedrop-win-value">16 <span class="rouble">&#8399;</span></span>
							</div>
						</div>
					</a>											<a class="livedrop-item green-spinner col-lg-1 js-livedrop-item" href="/user/428927784">
						<div class="livedrop-item-box">
							<img class="livedrop-img" src="/images/spinners/livedrop/green-spinner.png" alt="Green Spinner">
							<img class="user-livedrop-avatar" src="https://pp.userapi.com/c840024/v840024102/126de/duHQ8saUzHw.jpg" width="43">
							<div class="livedrop-win">
								<span class="livedrop-win-value">80 <span class="rouble">&#8399;</span></span>
							</div>
						</div>
					</a>											<a class="livedrop-item green-spinner col-lg-1 js-livedrop-item" href="/user/428927784">
						<div class="livedrop-item-box">
							<img class="livedrop-img" src="/images/spinners/livedrop/green-spinner.png" alt="Green Spinner">
							<img class="user-livedrop-avatar" src="https://pp.userapi.com/c840024/v840024102/126de/duHQ8saUzHw.jpg" width="43">
							<div class="livedrop-win">
								<span class="livedrop-win-value">80 <span class="rouble">&#8399;</span></span>
							</div>
						</div>
					</a>											<a class="livedrop-item green-spinner col-lg-1 js-livedrop-item" href="/user/428927784">
						<div class="livedrop-item-box">
							<img class="livedrop-img" src="/images/spinners/livedrop/green-spinner.png" alt="Green Spinner">
							<img class="user-livedrop-avatar" src="https://pp.userapi.com/c840024/v840024102/126de/duHQ8saUzHw.jpg" width="43">
							<div class="livedrop-win">
								<span class="livedrop-win-value">80 <span class="rouble">&#8399;</span></span>
							</div>
						</div>
					</a>											<a class="livedrop-item green-spinner col-lg-1 js-livedrop-item" href="/user/428927784">
						<div class="livedrop-item-box">
							<img class="livedrop-img" src="/images/spinners/livedrop/green-spinner.png" alt="Green Spinner">
							<img class="user-livedrop-avatar" src="https://pp.userapi.com/c840024/v840024102/126de/duHQ8saUzHw.jpg" width="43">
							<div class="livedrop-win">
								<span class="livedrop-win-value">80 <span class="rouble">&#8399;</span></span>
							</div>
						</div>
					</a>								
					<a class="livedrop-item yellow-spinner col-lg-1 js-livedrop-item" href="/user/428928273">
						<div class="livedrop-item-box">
							<img class="livedrop-img" src="/images/spinners/livedrop/yellow-spinner.png" alt="Yellow Spinner">
							<img class="user-livedrop-avatar" src="https://graph.facebook.com/v2.9/355827321539979/picture?type=normal" width="43">
							<div class="livedrop-win">
								<span class="livedrop-win-value">26 <span class="rouble">&#8399;</span></span>
							</div>
						</div>
					</a>
				</div>
			</div>
		</div>
		<div id="totalopens" class="text-center">
			<div class="container">
				<div class="pageblocktitle">
					<span>Всего открыто: <span class="font-bold color-primary js-total-opens">
						18452
					</span></span>
				</div>
			</div>
		</div>
		<div id="content">
		<div class="container">
		<div class="row justify-content-between">
			<?php if(isset($spinners)): ?>
				<?php foreach($spinners as $s): ?>
				<div class="col-lg-3 col-sm-6 col-md-6 col-xs-12">
					<div class="spinner <?php echo e($s->color); ?>-spinner">
						<a href="/spinner/<?php echo e($s->id); ?>">
							<div class="row">
								<div class="col-lg-6 text-left col-6">
									<span class="spinscount">
									<?php echo e($s->max_spin); ?>

									</span>
								</div>
								<div class="col-lg-6 text-right col-6">
									<span class="price"><span class="font-bold"><?php echo e($s->price); ?></span> <span class="rouble">&#8399;</span></span>
								</div>
							</div>
							<div class="image">
								<img src="<?php echo e($s->image); ?>" alt="<?php echo e($s->name); ?>">
							</div>
							<div class="name"><?php echo e($s->name); ?></div>
							<div class="open">Открыть</div>
							<span class="openscount">
								Возможный выигрыш: <span class="font-bold color-primary"><?php echo e($s->max_profit); ?> <span class="rouble">&#8399;</span></span>
							</span>
						</a>
					</div>
				</div>
				<?php endforeach; ?>
			<?php endif; ?>
							
		</div>
	</div>
	<div id="winnerstop">
		<div class="container text-center">
			<div class="pageblocktitle">
				<span>Топ победителей</span>
			</div>
			<div class="text-left">
									<div class="winner">
						<a class="row" href="/user/65201870">
							<div class="col-lg-8 col-sm-8 col-4">
								<span class="place">1</span>
								<img class="avatar" src="https://pp.userapi.com/c629119/v629119928/cba6/QjidDSydl1Y.jpg" alt="Rei Penbar">
								<span class="name">Rei Penbar</span>
							</div>
							<div class="col-lg-4 col-sm-4 col-8 text-right">
								<span class="spinscount">471</span>
								<span class="color-primary moneywon font-light"><span class="font-bold">136193</span> <span class="rouble">&#8399;</span></span>
							</div>
						</a>
					</div>
									<div class="winner">
						<a class="row" href="/user/218994520">
							<div class="col-lg-8 col-sm-8 col-4">
								<span class="place">2</span>
								<img class="avatar" src="https://pp.userapi.com/c637117/v637117520/328a4/K3JI_jFixBk.jpg" alt="Alexander Lorents">
								<span class="name">Alexander Lorents</span>
							</div>
							<div class="col-lg-4 col-sm-4 col-8 text-right">
								<span class="spinscount">385</span>
								<span class="color-primary moneywon font-light"><span class="font-bold">126795</span> <span class="rouble">&#8399;</span></span>
							</div>
						</a>
					</div>
									<div class="winner">
						<a class="row" href="/user/428925278">
							<div class="col-lg-8 col-sm-8 col-4">
								<span class="place">3</span>
								<img class="avatar" src="https://pp.userapi.com/c836132/v836132011/4b296/3u5MOuA4Zpw.jpg" alt="Vladimir Kovalenko">
								<span class="name">Vladimir Kovalenko</span>
							</div>
							<div class="col-lg-4 col-sm-4 col-8 text-right">
								<span class="spinscount">100</span>
								<span class="color-primary moneywon font-light"><span class="font-bold">88381</span> <span class="rouble">&#8399;</span></span>
							</div>
						</a>
					</div>
									<div class="winner">
						<a class="row" href="/user/428928027">
							<div class="col-lg-8 col-sm-8 col-4">
								<span class="place">4</span>
								<img class="avatar" src="https://pp.userapi.com/c638127/v638127809/529d1/-nm1EEuwXw0.jpg" alt="Eldar Dzharakhov">
								<span class="name">Eldar Dzharakhov</span>
							</div>
							<div class="col-lg-4 col-sm-4 col-8 text-right">
								<span class="spinscount">1004</span>
								<span class="color-primary moneywon font-light"><span class="font-bold">70222</span> <span class="rouble">&#8399;</span></span>
							</div>
						</a>
					</div>
									<div class="winner">
						<a class="row" href="/user/428925283">
							<div class="col-lg-8 col-sm-8 col-4">
								<span class="place">5</span>
								<img class="avatar" src="https://graph.facebook.com/v2.9/1999313670312038/picture?type=normal" alt="Maxim Shubin">
								<span class="name">Maxim Shubin</span>
							</div>
							<div class="col-lg-4 col-sm-4 col-8 text-right">
								<span class="spinscount">43</span>
								<span class="color-primary moneywon font-light"><span class="font-bold">52086</span> <span class="rouble">&#8399;</span></span>
							</div>
						</a>
					</div>
									<div class="winner">
						<a class="row" href="/user/428928024">
							<div class="col-lg-8 col-sm-8 col-4">
								<span class="place">6</span>
								<img class="avatar" src="https://vk.com/images/camera_50.png" alt="Alexandr-Valeryevich Burmistrov">
								<span class="name">Alexandr-Valeryevich Burmistrov</span>
							</div>
							<div class="col-lg-4 col-sm-4 col-8 text-right">
								<span class="spinscount">633</span>
								<span class="color-primary moneywon font-light"><span class="font-bold">46706</span> <span class="rouble">&#8399;</span></span>
							</div>
						</a>
					</div>
									<div class="winner">
						<a class="row" href="/user/428928369">
							<div class="col-lg-8 col-sm-8 col-4">
								<span class="place">7</span>
								<img class="avatar" src="https://pp.userapi.com/c638918/v638918658/424dc/9FQc3XmRVrI.jpg" alt="Denis Zhidkov">
								<span class="name">Denis Zhidkov</span>
							</div>
							<div class="col-lg-4 col-sm-4 col-8 text-right">
								<span class="spinscount">194</span>
								<span class="color-primary moneywon font-light"><span class="font-bold">41874</span> <span class="rouble">&#8399;</span></span>
							</div>
						</a>
					</div>
									<div class="winner">
						<a class="row" href="/user/428928967">
							<div class="col-lg-8 col-sm-8 col-4">
								<span class="place">8</span>
								<img class="avatar" src="https://pp.userapi.com/c621705/v621705578/d85f/c9DEpbgol20.jpg" alt="Advard Dalganiuk">
								<span class="name">Advard Dalganiuk</span>
							</div>
							<div class="col-lg-4 col-sm-4 col-8 text-right">
								<span class="spinscount">583</span>
								<span class="color-primary moneywon font-light"><span class="font-bold">36796</span> <span class="rouble">&#8399;</span></span>
							</div>
						</a>
					</div>
									<div class="winner">
						<a class="row" href="/user/428927820">
							<div class="col-lg-8 col-sm-8 col-4">
								<span class="place">9</span>
								<img class="avatar" src="https://pp.userapi.com/c837624/v837624720/5acc5/rKvr1ytynEY.jpg" alt="Ilya Shekhtman">
								<span class="name">Ilya Shekhtman</span>
							</div>
							<div class="col-lg-4 col-sm-4 col-8 text-right">
								<span class="spinscount">660</span>
								<span class="color-primary moneywon font-light"><span class="font-bold">35944</span> <span class="rouble">&#8399;</span></span>
							</div>
						</a>
					</div>
									<div class="winner">
						<a class="row" href="/user/428927882">
							<div class="col-lg-8 col-sm-8 col-4">
								<span class="place">10</span>
								<img class="avatar" src="https://pp.userapi.com/c637218/v637218774/108c4/ZcRvzFoy5xk.jpg" alt="Yulia Klyushina">
								<span class="name">Yulia Klyushina</span>
							</div>
							<div class="col-lg-4 col-sm-4 col-8 text-right">
								<span class="spinscount">328</span>
								<span class="color-primary moneywon font-light"><span class="font-bold">33995</span> <span class="rouble">&#8399;</span></span>
							</div>
						</a>
					</div>
									<div class="winner">
						<a class="row" href="/user/428928260">
							<div class="col-lg-8 col-sm-8 col-4">
								<span class="place">11</span>
								<img class="avatar" src="https://pp.userapi.com/c836122/v836122557/53545/hRg6IgMGKpE.jpg" alt="Ivan Kiselyov">
								<span class="name">Ivan Kiselyov</span>
							</div>
							<div class="col-lg-4 col-sm-4 col-8 text-right">
								<span class="spinscount">536</span>
								<span class="color-primary moneywon font-light"><span class="font-bold">32295</span> <span class="rouble">&#8399;</span></span>
							</div>
						</a>
					</div>
									<div class="winner">
						<a class="row" href="/user/428927657">
							<div class="col-lg-8 col-sm-8 col-4">
								<span class="place">12</span>
								<img class="avatar" src="https://pp.userapi.com/c637327/v637327700/5843d/A464jnAGD4I.jpg" alt="Sergey Filonenko">
								<span class="name">Sergey Filonenko</span>
							</div>
							<div class="col-lg-4 col-sm-4 col-8 text-right">
								<span class="spinscount">536</span>
								<span class="color-primary moneywon font-light"><span class="font-bold">31445</span> <span class="rouble">&#8399;</span></span>
							</div>
						</a>
					</div>
							</div>
		</div>
	</div>
	<div id="features">
		<div class="container text-center">
			<div class="pageblocktitle">
				<span>Наши преимущества</span>
			</div>
			<div class="text-left row">
				<div class="col-lg-3 feature">
					<div class="icon icon-original"></div>
					<div class="name">Оригинальность</div>
					<div class="description">Мы единственные, кто связал трендовую вещь с интересным функционалом!</div>
				</div>
				<div class="col-lg-3 feature">
					<div class="icon icon-fast"></div>
					<div class="name">Быстрые выплаты</div>
					<div class="description">Мы гарантируем каждую выплату без комиссии. Минимальное время - 1 минута. В некоторых случаях придется подождать, но не более 24 часов!</div>
				</div>
				<div class="col-lg-3 feature">
					<div class="icon icon-safe"></div>
					<div class="name">Безопасность</div>
					<div class="description">Мы не имеем доступа к вашим аккаунтам в социальных сетях и не публикуем конфиденциальную информацию</div>
				</div>
				<div class="col-lg-3 feature">
					<div class="icon icon-clear"></div>
					<div class="name">Прозрачность</div>
					<div class="description">Мы подробно рассказываем о работе системы и показываем каждый выигрыш!</div>
				</div>
			</div>
		</div>
	</div>
		</div>
		<div id="globalfooter">
			<div class="row container">
				<div class="col-lg-4">
					<p class="copyright">Авторизуясь на сайте, вы принимаете <br><a style="display:inline" href="/policy" class="color-primary">пользовательское соглашение</a> и подтверждаете, <br> что вам 18 и более лет.</p>
					<p class="">2017 © spinmoney.online<br>Все права защищены.</p>
				</div>
				<div class="col-lg-2">
					<div class="footer-contacts">
					<p style="margin-bottom:4px">По всем вопросам: </p>
					<p class="" style="margin-bottom:9px;"><a class="__cf_email__" href="/cdn-cgi/l/email-protection" data-cfemail="10636560607f6264506360797e7d7f7e75693e7f7e7c797e75">[email&#160;protected]</a><script data-cfhash='f9e31' type="text/javascript">/* <![CDATA[ */!function(t,e,r,n,c,a,p){try{t=document.currentScript||function(){for(t=document.getElementsByTagName('script'),e=t.length;e--;)if(t[e].getAttribute('data-cfhash'))return t[e]}();if(t&&(c=t.previousSibling)){p=t.parentNode;if(a=c.getAttribute('data-cfemail')){for(e='',r='0x'+a.substr(0,2)|0,n=2;a.length-n;n+=2)e+='%'+('0'+('0x'+a.substr(n,2)^r).toString(16)).slice(-2);p.replaceChild(document.createTextNode(decodeURIComponent(e)),c)}p.removeChild(t)}}catch(u){}}()/* ]]> */</script></p>
					<a href="https://www.free-kassa.ru/"><img src="https://www.free-kassa.ru/img/fk_btn/14.png" alt="Pay by freekassa"></a>
					</div>
				</div>
				<div class="col-lg-1"></div>
				<div class="col-lg-5">
					<p style="font-size:16px">Мы принимаем:</p>
					<div class="row">
						<div class="col-lg-3 col-md-3 col-sm-3 col-3">
							<img src="/images/card-light-icon.png" alt="Банковские карты">
						</div>
						<div class="col-lg-3 col-md-3 col-sm-3 col-3">
							<img src="/images/yandexmoney-light-icon.png" alt="Яндекс.Деньги">
						</div>
						<div class="col-lg-3 col-md-3 col-sm-3 col-3">
							<img src="/images/qiwi-light-icon.png" alt="Qiwi">
						</div>
						<div class="col-lg-3 col-md-3 col-sm-3 col-3">
							<img src="/images/payeer-light-icon.png" alt="Payeer">
						</div>
						<div class="col-lg-3 col-md-3 col-sm-3 col-3">
							<img src="/images/mts-light-icon.png" alt="МТС">
						</div>
						<div class="col-lg-3 col-md-3 col-sm-3 col-3">
							<img src="/images/megafon-light-icon.png" alt="Мегафон">
						</div>
						<div class="col-lg-3 col-md-3 col-sm-3 col-3">
							<img src="/images/tele2-light-icon.png" alt="Теле2">
						</div>
						<div class="col-lg-3 col-md-3 col-sm-3 col-3">
							<img src="/images/beeline-light-icon.png" alt="Билайн">
						</div>
					</div>
				</div>
			</div>
		</div>

		<div id="withdrawmodal" class="modal fade show" role="dialog" style="display: none; padding-right: 17px;">
	<div class="modal-dialog">
		<div class="modal-header">
			<div class="col-lg-8 col-sm-8 col-12 modal-title">
				Вывести средства
			</div>
			<div class="col-lg-4 text-right">
				<i class="fa fa-close" data-dismiss="modal"></i>
			</div>
		</div>
		<div class="modal-body">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<p>Выберите платежную систему:</p>
					<div class="row">
						<div class="col-lg-3 col-sm-3 col-md-3 col-3 wallet wallet-card js-withdraw-wallet" data-currency-id="94"></div>
						<div class="col-lg-3 col-sm-3 col-md-3 col-3 wallet wallet-ooopay js-withdraw-wallet" data-currency-id="106"></div>
						<div class="col-lg-3 col-sm-3 col-md-3 col-3 wallet wallet-qiwi js-withdraw-wallet" data-currency-id="63"></div>
						<div class="col-lg-3 col-sm-3 col-md-3 col-3 wallet wallet-payeer js-withdraw-wallet" data-currency-id="114"></div>
						<div class="col-lg-3 col-sm-3 col-md-3 col-3 wallet wallet-wmr js-withdraw-wallet" data-currency-id="1"></div>
						<div class="col-lg-3 col-sm-3 col-md-3 col-3 wallet wallet-yandexmoney js-withdraw-wallet" data-currency-id="45"></div>
					</div>
				</div>
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<p>Сумма:</p>
					<input type="text" value="100" class="sum js-withdraw-sum">
				</div>
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<p>Кошелек:</p>
					<input type="text" value="" class="number js-withdraw-number">
				</div>
			</div>
			<div class="text-center">
								<button type="button" class="withdraw js-withdraw">Вывести</button>
			</div>	
		</div>
	</div>
</div>
		<!--SCRIPTS-->
			<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/socket.io/2.0.3/socket.io.js"></script>
			<script src="https://npmcdn.com/tether@1.2.4/dist/js/tether.min.js"></script>
			<script src="/js/bootstrap.min.js"></script>
			<script src="/js/Utils.js"></script>
						<script src="/js/SocketModule.js"></script>
			<script src="/js/LiveDropModule.js?1503228428"></script>
			<script src="/js/nouislider.min.js"></script>
				<script>
				(function() {
				SocketModule.connect("https://spinmoney.online", "/ws/");
					LiveDropModule.init({
						"liveDropBlock":"#livedrop .js-livedrop",
						"liveDropItems":"#livedrop .js-livedrop-item",
						"totalOpens":".js-total-opens",
						"socketModule":SocketModule
					});
				})();
			</script>
			<script>
				$(window).scroll(function (event) {
					var y = $(this).scrollTop();
					if ($(this).scrollTop() > 20 ) {
						$('body').addClass('fix-menu');
						$('.globalheader').addClass('stuck');

					} else {
						$('body').removeClass('fix-menu');
						$('.globalheader').removeClass('stuck');
					}
				});
				$('.globalheader .menu-btn').on('click', function() {
					$(this).next().slideToggle();
				});
			</script>
			<script type="text/javascript" src="//vk.com/js/api/openapi.js?146"></script>

<!-- VK Widget -->
<div id="vk_community_messages"></div>
<script type="text/javascript">
	VK.Widgets.CommunityMessages("vk_community_messages", 150730389, {tooltipButtonText: "Есть вопрос?"});
</script>
		<!--/SCRIPTS-->
	</body>
</html>

