<?php $__env->startSection('content'); ?>
<div class="page-bar">
	<ul class="page-breadcrumb">
		<li>
			<a href="/admin">Главная</a>
			<i class="fa fa-circle"></i>
		</li>
		<li>
			<span>Выводы</span>
		</li>
	</ul>
</div>

<h1 class="page-title"> Выводы пользователей </h1>

<div class="flash-message">
    <?php foreach(['danger', 'warning', 'success', 'info'] as $msg): ?>
      <?php if(Session::has('alert-' . $msg)): ?>

      <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
      <?php endif; ?>
    <?php endforeach; ?>
</div>

<div class="row">
	<div class="col-md-12">
		<div class="portlet light bordered">
			<div class="portlet-body">
				<table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
					<thead>
						<tr>
							<th>ID</th>
							<th>Пользователь</th>
							<th>Система</th>
							<th>Кошелек</th>
							<th>Сумма</th>
							<th>Время</th>
							<th>Статус</th>
							<th>Редактировать</th>
						</tr>
					</thead>
					<tbody>
						<?php foreach($withdrows as $w): ?>
						<tr>
							<td style="vertical-align: middle;"><?php echo e($w->id); ?></td>
							<td style="vertical-align: middle;"><a href="https://vk.com/<?php echo e($w->user->login); ?>" target="_blank"><?php echo e($w->user->username); ?></a></td>
							<td style="vertical-align: middle;"><?php if(isset($w->wallet)): ?>
																<?php if($w->wallet == 63): ?>
																<center><img src="/images/qiwi-light-icon.png" width="50px" alt = 'Qiwi Visa Wallet' title="Qiwi"></center>
																<?php elseif($w->wallet == 94): ?>
																<center><img src="/images/card-light-icon.png" width="50px" alt = 'Card' title="Cards"></center>
																<?php elseif($w->wallet == 106): ?>
																<center><img src="/images/ooopay-icon.png" width="50px" alt = 'OOO Pay' title="OOO Pay"></center>
																<?php elseif($w->wallet == 114): ?>
																<center><img src="/images/payeer-light-icon.png" width="50px" alt = 'Payeer' title="Payeer"></center>
																<?php elseif($w->wallet == 1): ?>
																<center><img src="/images/wmr-icon.png" width="50px" alt = 'WebMoney' title="WebMoney"></center>
																<?php elseif($w->wallet == 45): ?>
																<center><img src="/images/yandexmoney-light-icon.png" width="50px" alt = 'YandexMoney' title="YandexMoney"></center>
																</td>
																<?php endif; ?>
																<?php endif; ?>
							<td style="vertical-align: middle;"><?php echo e($w->number); ?></td>
							<td style="vertical-align: middle;"><?php echo e($w->amount); ?></td>
							<td style="vertical-align: middle;"><?php echo e($w->dfh); ?></td>
							<?php if(isset($w->status)): ?>
							<td style="vertical-align: middle;">
								<?php if($w->status == 0): ?>
								<div class="btn green btn-sm">Ожидает</div>
								<?php elseif($w->status == 1): ?>
								<div class="btn orange btn-sm">Выплачено</div>
								<?php endif; ?>
							</td>
							<?php endif; ?>
							<td style="vertical-align: middle;"><?php if(isset($w->status) && isset($w->id)): ?> <?php if($w->status == 0): ?><a class="btn blue btn-sm" data-toggle="modal" data-target="#usr_edit" href="/admin/withdraw/<?php echo e($w->id); ?>/edit">Редактировать</a><?php endif; ?> <?php endif; ?></td>
						</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<div class="modal fade" id="usr_edit" tabindex="-1" role="basic" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<?php if(isset($w)): ?>
			<?php echo $__env->make('admin.includes.modal_withdrows', ['user' => $w], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php else: ?>
			<?php endif; ?>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>