

<?php $__env->startSection('content'); ?>
		<div id="content">
		<div class="container">
		<div class="row justify-content-between">
			<?php if(isset($spinners)): ?>
				<?php foreach($spinners as $s): ?>
				<div class="col-lg-3 col-sm-6 col-md-6 col-xs-12">
					<div class="spinner <?php echo e($s->color); ?>-spinner">
						<a href="/spinner/<?php echo e($s->id); ?>">
							<div class="row">
								<div class="col-lg-6 text-left col-6">
									<span class="spinscount">
									<?php echo e($s->max_spin); ?>

									</span>
								</div>
								<div class="col-lg-6 text-right col-6">
									<span class="price"><span class="font-bold"><?php echo e($s->price); ?></span> <span class="rouble">&#8399;</span></span>
								</div>
							</div>
							<div class="image">
								<img src="<?php echo e($s->image); ?>" alt="<?php echo e($s->name); ?>">
							</div>
							<div class="name"><?php echo e($s->name); ?></div>
							<div class="open">Открыть</div>
							<span class="openscount">
								Возможный выигрыш: <span class="font-bold color-primary"><?php echo e($s->max_profit); ?> <span class="rouble">&#8399;</span></span>
							</span>
						</a>
					</div>
				</div>
				<?php endforeach; ?>
			<?php endif; ?>
							
		</div>
	</div>
	<div id="winnerstop">
		<div class="container text-center">
			<div class="pageblocktitle">
				<span>Топ победителей</span>
			</div>
			<div class="text-left">
					<?php 
					$i = 1;
					 ?>
					<?php foreach($winners as $w): ?>
					<div class="winner">
						<a class="row" href="/user/<?php echo e($w->id); ?>">
							<div class="col-lg-8 col-sm-8 col-4">
								<span class="place"><?php echo e($i); ?></span>
								<img class="avatar" src="<?php echo e($w->avatar); ?>" alt="<?php echo e($w->username); ?>">
								<span class="name"><?php echo e($w->username); ?></span>
							</div>
							<div class="col-lg-4 col-sm-4 col-8 text-right">
								<span class="spinscount"><?php echo e($w->total); ?></span>
								<span class="color-primary moneywon font-light"><span class="font-bold"><?php echo e($w->profit); ?></span> <span class="rouble">&#8399;</span></span>
							</div>
						</a>
					</div>
					<?php 
					$i++;
					 ?>
					<?php endforeach; ?>
					
			</div>
		</div>
	</div>
	<div id="features">
		<div class="container text-center">
			<div class="pageblocktitle">
				<span>Наши преимущества</span>
			</div>
			<div class="text-left row">
				<div class="col-lg-3 feature">
					<div class="icon icon-original"></div>
					<div class="name">Оригинальность</div>
					<div class="description">Мы единственные, кто связал трендовую вещь с интересным функционалом!</div>
				</div>
				<div class="col-lg-3 feature">
					<div class="icon icon-fast"></div>
					<div class="name">Быстрые выплаты</div>
					<div class="description">Мы гарантируем каждую выплату без комиссии. Минимальное время - 1 минута. В некоторых случаях придется подождать, но не более 24 часов!</div>
				</div>
				<div class="col-lg-3 feature">
					<div class="icon icon-safe"></div>
					<div class="name">Безопасность</div>
					<div class="description">Мы не имеем доступа к вашим аккаунтам в социальных сетях и не публикуем конфиденциальную информацию</div>
				</div>
				<div class="col-lg-3 feature">
					<div class="icon icon-clear"></div>
					<div class="name">Прозрачность</div>
					<div class="description">Мы подробно рассказываем о работе системы и показываем каждый выигрыш!</div>
				</div>
			</div>
		</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>