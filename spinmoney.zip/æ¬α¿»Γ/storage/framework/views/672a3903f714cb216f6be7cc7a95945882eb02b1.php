<?php $__env->startSection('content'); ?>
<div class="page-bar">
	<ul class="page-breadcrumb">
		<li>
			<a href="/admin">Главная</a>
			<i class="fa fa-circle"></i>
		</li>
		<li>
			<span>Редактировать спиннер</span>
		</li>
	</ul>
</div>

<h1 class="page-title"> Редактирование спиннера </h1>

<div class="flash-message">
    <?php foreach(['danger', 'warning', 'success', 'info'] as $msg): ?>
      <?php if(Session::has('alert-' . $msg)): ?>

      <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
      <?php endif; ?>
    <?php endforeach; ?>
</div> <!-- end .flash-message -->

<div class="row">
	<div class="col-md-12">
		<div class="portlet light bordered">
			<div class="portlet-body">
				<form method="post" action="/admin/case/update" class="horizontal-form" id="save">
					<input name="id" value="<?php echo e($case->id); ?>" type="hidden">
					<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
					<div class="form-body">
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label class="control-label"><b>Название</b></label>
									<input type="text" class="form-control" placeholder="Название спинера" name="name" value="<?php echo e($case->name); ?>">
								</div>
							</div>
							<!--/span-->
							<div class="col-md-6">
								<div class="form-group">
									<label class="control-label"><b>Цена</b></label>
									<input type="text" class="form-control" placeholder="0" name="price" value="<?php echo e($case->price); ?>">
								</div>
							</div>
							<!--/span-->
						</div>
						<!--/row-->
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label class="control-label"><b>Цвет</b></label>
									<input type="text" class="form-control" placeholder="Цвет спиннера" name="color" value="<?php echo e($case->color); ?>">
								</div>
							</div>
							<!--/span-->
							<div class="col-md-6">
								<div class="form-group">
									<label class="control-label"><b>Диапазон</b></label>
									<input type="text" class="form-control" placeholder="10" name="diapasone" value="<?php echo e($case->diapasone); ?>">
								</div>
							</div>
							<!--/span-->
						</div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label class="control-label"><b>Максимальное число оборотов</b></label>
									<input type="text" class="form-control" placeholder="Максимальное число оборотов" name="max_spin" value="<?php echo e($case->max_spin); ?>">
								</div>
							</div>
							<!--/span-->
							<div class="col-md-6">
								<div class="form-group">
									<label class="control-label"><b>Максимальный профит</b></label>
									<input type="text" class="form-control" placeholder="Максимальный выйгрыш" name="max_profit" value="<?php echo e($case->max_profit); ?>">
								</div>
							</div>
							<!--/span-->
						</div>
						<div class="row" style="margin-top: 10px;">
							<div class="col-md-12">
								<div class="form-group text-center">
									<label class="control-label"><b>Картинка</b></label>
									<div class="col-md-12">
										<input type="text" class="form-control" placeholder="Путь к картинке" name="image" value="<?php echo e($case->image); ?>">
										<img src="<?php echo e($case->image); ?>" width="100px">
									</div>
								</div>
							</div>
						</div>
						<div class="row" style="margin-top: 10px;
												margin-bottom: 10px;">
							<div class="col-md-12">
								<div class="form-group">
									<label class="col-md-12 control-label text-center"><b>Шанс окупаемости</b></label>
									<div class="col-md-12">
										<input id="range_1" type="text" name="chance" value="<?php echo e($case->chance); ?>"/>
									</div>
								</div>
							</div>
						</div>
					</div>
					
					<div class="form-actions right">
						<button type="submit" class="btn blue"><i class="fa fa-check"></i> Сохранить </button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>