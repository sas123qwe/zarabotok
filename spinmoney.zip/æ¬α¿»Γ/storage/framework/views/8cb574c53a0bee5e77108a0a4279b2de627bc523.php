

<?php $__env->startSection('content'); ?>
<div id="content">
	<div class="profile-page">
		<div class="container">
			<div class="row">
			<div class="col-lg-3 col-sm-3 col-md-3 col-12">
				<div class="profile-sidebar">
					<img src="<?php echo e($user->avatar); ?>" width="127px" height="127px">
					<p class="username"><?php echo e($user->username); ?></p>
				</div>
			</div>
			<div class="col-lg-9 col-sm-9 col-md-9 col-12">
				<div class="profile-inner">
					<div class="profile-head">
						<div class="tabs-row">
							<div class="item">
								<div class="stat tltp">
									<i class="icon-spin-count"></i>
									<span class="value"><?php echo e($user->spinners); ?></span>
									<div class="tooltiptext">Открыто спиннеров</div>
								</div>
							</div>
							<div class="item">
								<div class="stat tltp">
									<i class="icon-partner"></i>
									<span class="value"><?php echo e($user->referals); ?></span>
									<div class="tooltiptext">Привлечено рефералов</div>
								</div>
							</div>
							<div class="item">
								<div class="stat tltp">
									<i class="icon-money"></i>
									<span class="value"><?php echo e($user->profit); ?> <span class="rouble" style="margin-left:0;vertical-align: top;">₽</span></span>
									<div class="tooltiptext">Всего выиграно</div>
								</div>
							</div>
						</div>
					</div>
					<div class="profile-content">
						<div class="container" id="spins">
							<div class="pageblocktitle">
								<span>История игр</span>
							</div>
							<div class="pageinner">
								<div class="wins-list js-wins row">
									<?php foreach($wins as $w): ?>
									<a class="livedrop-item <?php echo e($w->color); ?>-spinner col-lg-1 js-livedrop-item" href="/spinner/<?php echo e($w->spinner_id); ?>">
										<div class="livedrop-item-box">
											<img class="livedrop-img" src="/images/spinners/livedrop/<?php echo e($w->color); ?>-spinner.png">
											<div class="livedrop-win">
												<span class="livedrop-win-value"><?php echo e($w->win); ?> <span class="rouble">₽</span></span>
											</div>
										</div>
									</a>
									<?php endforeach; ?>							
								</div>
								<div class="text-center">
									<button class="js-load-wins btn">Показать еще</button>
								</div>
								<br>
							</div>
						</div>
					</div>
				</div>
			</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="/js/UserModule.js"></script>
<script>
	UserModule.init({
		"blockWins":".js-wins",
		"buttonLoadWins":".js-load-wins",
		"csrf":"<?php echo e(csrf_token()); ?>",
		"blockWinsPage":1,
		"userId":"<?php echo e($user->id); ?>"
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>