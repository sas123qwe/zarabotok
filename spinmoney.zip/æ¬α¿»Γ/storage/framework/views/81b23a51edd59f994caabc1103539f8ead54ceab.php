<!DOCTYPE html>
<html lang="ru">
	<head>
		<title>SpinMoney – крути и угадывай, открывай кейсы с деньгами и выигрывай</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="yandex-verification" content="54ed8458eb078834" />
		<meta name="description" content="Открывай кейсы с деньгами и выигрывай деньги" />
		<meta name="keywords" content="открытие кейсов,кейсы с деньгами,кейсы,спиннер" />
		<link rel="shortcut icon" href="/images/favicon.ico?v=2" type="image/x-icon">
		<link rel="icon" href="/images/favicon.ico?v=2" type="image/x-icon">

		<link href="/css/bootstrap.min.css" rel="stylesheet" type="text/css">
		<link href="/css/font-awesome.min.css" rel="stylesheet" type="text/css">
		<link href="/css/nouislider.css" rel="stylesheet" type="text/css">
		<link href="/css/layout.css?1503228428" rel="stylesheet" type="text/css">
		<link href="/css/adaptive.css?1503228428" rel="stylesheet" type="text/css">
		<script type="text/javascript" src="//vk.com/js/api/openapi.js?146"></script>

		<script type="text/javascript">
		  VK.init({apiId: 5771677, onlyWidgets: true});
		</script>
	</head>
	<body>

		<div class="globalheader">
			<div class="container">
				<div class="row">
					<div class="col-lg-3 col-md-3 col-sm-4 col-4">
						<a href="/"><img id="logo" src="/images/logo.png" alt="SpinMoney"></a>
					</div>
					<div class="menu col-lg-7 col-md-7 col-sm-4 col-4 text-center">
						<button class="menu-btn btn" style="margin-top: 0;display:none;">Меню</button>
						<div class="menu-list">
						<a href="/help">Помощь</a>
						<a href="/reviews">Отзывы</a>
						<a href="<?php if(Auth::guest()): ?> # <?php else: ?> /profile#partner <?php endif; ?>">Партнерская программа</a>
						<?php if(!Auth::guest()): ?>
						<a onclick="$('#withdrawmodal').modal('show');">Вывод средств</a>
						<?php endif; ?>
					</div>
					</div>
					<div class="profile col-lg-2 col-md-2 col-sm-4 col-4">
							<?php if(Auth::guest()): ?>
							<div class="row nonautorized pull-right">
								<span>Войти через:</span>
								<a href="/login"><i class="fa fa-vk fa-2x"></i></a>
							</div>
							<?php else: ?>
							<div class="row autorized">
								<div class="col-lg-10 col-sm-9 col-9 text-right">
									<div class="profile-box">
										<a class="link" href="/profile">Мой профиль</a>
										<div>
											<a onclick="$('#refillmodal').modal('show');" class="add-funds">
												<span class="color-primary font-bold">
												<?php if(Auth::user()->money != 0): ?>
												<span class="js-balance"><?php echo e(Auth::user()->money); ?></span><span class="rouble">₽</span></span> 
												<?php else: ?>
												<span class="js-balance">Пополнить</span></span> 
												<?php endif; ?>
												<i class="icon-add-founds"></i>
											</a>
										</div>
									</div>
								</div>
								<a class="col-lg-2 col-sm-3 col-3 text-right" href="/profile">
									<img src="<?php echo e(Auth::user()->avatar); ?>" alt="<?php echo e(Auth::user()->username); ?>">
								</a>
							</div>
							<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
		<div id="livedrop">
			<div class="container">
				<span class="live-span" style="">LIVE</span>
				<span class="vk-btn" style=""><a target="_blank" href="https://vk.com/spinmoneyonline" style="
				    color: #fff;
				    font-size: 13px;
				    /* display: none; */
				"><img src="http://piterpen35.ru/images/vk.png" style="
				    width: 80px;
				">
				</a></span>
				<div class="row js-livedrop">
					<?php if(isset($drops)): ?>
					<?php foreach($drops as $d): ?>
					<a class="livedrop-item <?php echo e($d->color); ?>-spinner col-lg-1 js-livedrop-item" href="/user/<?php echo e($d->user_id); ?>">
						<div class="livedrop-item-box">
							<img class="livedrop-img" src="/images/spinners/livedrop/<?php echo e($d->color); ?>-spinner.png" alt="<?php echo e($d->color); ?> Spinner">
							<img class="user-livedrop-avatar" src="<?php echo e($d->avatar); ?>" width="43">
							<div class="livedrop-win">
								<span class="livedrop-win-value"><?php echo e($d->win); ?> <span class="rouble">&#8399;</span></span>
							</div>
						</div>
					</a>
					<?php endforeach; ?>
					<?php endif; ?>
				</div>
			</div>
		</div>
		<div id="totalopens" class="text-center">
			<div class="container">
				<div class="pageblocktitle">
					<span>Всего открыто: <span class="font-bold color-primary js-total-opens">
					<?php echo e($total); ?>

					</span></span>
				</div>
			</div>
		</div>
		<?php echo $__env->yieldContent('content'); ?>
		<div id="globalfooter">
		<div id="refillmodal" class="modal fade show" role="dialog" style="display: none;">
	<div class="modal-dialog">
		<div class="modal-header">
			<div class="col-9 modal-title">
				Пополнить баланс
			</div>
			<div class="col-2 text-right">
				<i class="fa fa-close modal-close" data-dismiss="modal"></i>
			</div>
		</div>
		<div class="modal-body row">
			<div class="col-12 text-center">
				<p>Выберите способ пополнения:</p>
				<div>
					<div class="wallet wallet-card js-refill-wallet" data-currency-id="94"></div>
					<div class="wallet wallet-qiwi js-refill-wallet" data-currency-id="63"></div>
					<div class="wallet wallet-yandexmoney js-refill-wallet" data-currency-id="45"></div>
					<div class="wallet wallet-payeer js-refill-wallet" data-currency-id="114"></div>
					<div class="wallet wallet-beeline js-refill-wallet" data-currency-id="83"></div>
					<div class="wallet wallet-mts js-refill-wallet" data-currency-id="84"></div>
					<div class="wallet wallet-megafon js-refill-wallet" data-currency-id="82"></div>
					<div class="wallet wallet-tele2 js-refill-wallet" data-currency-id="132"></div>
					<div class="wallet wallet-skinpay new js-refill-wallet" data-currency-id="154"></div>
				</div>
			</div>
			<div class="col-12 text-center">
				<p>Введите сумму:</p>
				<input type="text" value="100" class="sum js-refill-sum"><br>
				<button type="button" class="refill js-refill">Оплатить</button>
			</div>
			<div class="col-12 text-center">
				<p><span class="color-primary">Внимание!</span> После нажатия на кнопку, не меняйте сумму и примечание, иначе деньги не придут.</p>
			</div>
		</div>
	</div>
</div>
			<div class="row container">
				<div class="col-lg-4">
					<p class="copyright">Авторизуясь на сайте, вы принимаете <br><a style="display:inline" href="/policy" class="color-primary">пользовательское соглашение</a> и подтверждаете, <br> что вам 18 и более лет.</p>
					<p class="">2017 © spinmoney.online<br>Все права защищены.</p>
				</div>
				<div class="col-lg-2">
					<div class="footer-contacts">
					<p style="margin-bottom:4px">По всем вопросам: </p>
					<p class="" style="margin-bottom:9px;"><a class="__cf_email__" href="/cdn-cgi/l/email-protection" data-cfemail="10636560607f6264506360797e7d7f7e75693e7f7e7c797e75">[email&#160;protected]</a><script data-cfhash='f9e31' type="text/javascript">/* <![CDATA[ */!function(t,e,r,n,c,a,p){try{t=document.currentScript||function(){for(t=document.getElementsByTagName('script'),e=t.length;e--;)if(t[e].getAttribute('data-cfhash'))return t[e]}();if(t&&(c=t.previousSibling)){p=t.parentNode;if(a=c.getAttribute('data-cfemail')){for(e='',r='0x'+a.substr(0,2)|0,n=2;a.length-n;n+=2)e+='%'+('0'+('0x'+a.substr(n,2)^r).toString(16)).slice(-2);p.replaceChild(document.createTextNode(decodeURIComponent(e)),c)}p.removeChild(t)}}catch(u){}}()/* ]]> */</script></p>
					<a href="https://www.free-kassa.ru/"><img src="https://www.free-kassa.ru/img/fk_btn/14.png" alt="Pay by freekassa"></a>
					</div>
				</div>
				<div class="col-lg-1"></div>
				<div class="col-lg-5">
					<p style="font-size:16px">Мы принимаем:</p>
					<div class="row">
						<div class="col-lg-3 col-md-3 col-sm-3 col-3">
							<img src="/images/card-light-icon.png" alt="Банковские карты">
						</div>
						<div class="col-lg-3 col-md-3 col-sm-3 col-3">
							<img src="/images/yandexmoney-light-icon.png" alt="Яндекс.Деньги">
						</div>
						<div class="col-lg-3 col-md-3 col-sm-3 col-3">
							<img src="/images/qiwi-light-icon.png" alt="Qiwi">
						</div>
						<div class="col-lg-3 col-md-3 col-sm-3 col-3">
							<img src="/images/payeer-light-icon.png" alt="Payeer">
						</div>
						<div class="col-lg-3 col-md-3 col-sm-3 col-3">
							<img src="/images/mts-light-icon.png" alt="МТС">
						</div>
						<div class="col-lg-3 col-md-3 col-sm-3 col-3">
							<img src="/images/megafon-light-icon.png" alt="Мегафон">
						</div>
						<div class="col-lg-3 col-md-3 col-sm-3 col-3">
							<img src="/images/tele2-light-icon.png" alt="Теле2">
						</div>
						<div class="col-lg-3 col-md-3 col-sm-3 col-3">
							<img src="/images/beeline-light-icon.png" alt="Билайн">
						</div>
					</div>
				</div>
			</div>
		</div>

		<div id="withdrawmodal" class="modal fade show" role="dialog" style="display: none; padding-right: 17px;">
	<div class="modal-dialog">
		<div class="modal-header">
			<div class="col-lg-8 col-sm-8 col-12 modal-title">
				Вывести средства
			</div>
			<div class="col-lg-4 text-right">
				<i class="fa fa-close" data-dismiss="modal"></i>
			</div>
		</div>
		<div class="modal-body">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<p>Выберите платежную систему:</p>
					<div class="row">
						<div class="col-lg-3 col-sm-3 col-md-3 col-3 wallet wallet-card js-withdraw-wallet" data-currency-id="94"></div>
						<div class="col-lg-3 col-sm-3 col-md-3 col-3 wallet wallet-ooopay js-withdraw-wallet" data-currency-id="106"></div>
						<div class="col-lg-3 col-sm-3 col-md-3 col-3 wallet wallet-qiwi js-withdraw-wallet" data-currency-id="63"></div>
						<div class="col-lg-3 col-sm-3 col-md-3 col-3 wallet wallet-payeer js-withdraw-wallet" data-currency-id="114"></div>
						<div class="col-lg-3 col-sm-3 col-md-3 col-3 wallet wallet-wmr js-withdraw-wallet" data-currency-id="1"></div>
						<div class="col-lg-3 col-sm-3 col-md-3 col-3 wallet wallet-yandexmoney js-withdraw-wallet" data-currency-id="45"></div>
					</div>
				</div>
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<p>Сумма:</p>
					<input type="text" value="100" class="sum js-withdraw-sum">
				</div>
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<p>Кошелек:</p>
					<input type="text" value="" class="number js-withdraw-number">
				</div>
			</div>
			<div class="text-center">
				<button type="button" class="withdraw js-withdraw">Вывести</button>
			</div>	
		</div>
	</div>
</div>
		<!--SCRIPTS-->
			<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/socket.io/2.0.3/socket.io.js"></script>
			<script src="https://npmcdn.com/tether@1.2.4/dist/js/tether.min.js"></script>
			<script src="/js/bootstrap.min.js"></script>
			<script src="/js/Utils.js"></script>
			<script src="/js/RefillModule.js"></script>
			<script src="/js/WithdrawModule.js"></script>
			<script src="/js/SocketModule.js"></script>
			<script src="/js/LiveDropModule.js?1503421508"></script>
			<script src="/js/nouislider.min.js"></script>
			<script>
				(function() {
				SocketModule.connect(":2019");
					LiveDropModule.init({
						"liveDropBlock":"#livedrop .js-livedrop",
						"liveDropItems":"#livedrop .js-livedrop-item",
						"totalOpens":".js-total-opens",
						"socketModule":SocketModule
					});
				})();
			</script>
			<script>
				(function() {
					RefillModule.init({
							"buttonWallet":".js-refill-wallet",
							"buttonRefill":".js-refill",
							"inputSum":".js-refill-sum",
							"csrf":"<?php echo e(csrf_token()); ?>"
						});
						WithdrawModule.init({
							"buttonWallet":".js-withdraw-wallet",
							"buttonWithdraw":".js-withdraw",
							"inputSum":".js-withdraw-sum",
							"inputNumber":".js-withdraw-number",
							"csrf":"<?php echo e(csrf_token()); ?>",
							"modal":"#withdrawmodal",
							"modal_success":'#withdrawmodal-success'
						});
				})();
			</script>
			
			<script>
				$(window).scroll(function (event) {
					var y = $(this).scrollTop();
					if ($(this).scrollTop() > 20 ) {
						$('body').addClass('fix-menu');
						$('.globalheader').addClass('stuck');

					} else {
						$('body').removeClass('fix-menu');
						$('.globalheader').removeClass('stuck');
					}
				});
				$('.globalheader .menu-btn').on('click', function() {
					$(this).next().slideToggle();
				});
			</script>
			<?php echo $__env->yieldContent('scripts'); ?>

		<!--/SCRIPTS-->
	</body>
</html>