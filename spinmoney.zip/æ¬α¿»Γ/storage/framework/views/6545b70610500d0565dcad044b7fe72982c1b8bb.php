<?php $__env->startSection('content'); ?>
<div class="page-bar">
	<ul class="page-breadcrumb">
		<li>
			<a href="/admin">Главная</a>
			<i class="fa fa-circle"></i>
		</li>
		<li>
			<span>Добавить спиннер</span>
		</li>
	</ul>
</div>

<h1 class="page-title"> Создание нового спиннера </h1>

<div class="row">
	<div class="col-md-12">
		<div class="portlet light bordered">
			<div class="portlet-body">
				<form method="post" action="/admin/case/save" class="horizontal-form" id="save">
					<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
					<div class="form-body">
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label class="control-label"><b>Название</b></label>
									<input type="text" class="form-control" placeholder="Название спиннера" name="name">
								</div>
							</div>
							<!--/span-->
							<div class="col-md-6">
								<div class="form-group">
									<label class="control-label"><b>Цена</b></label>
									<input type="text" class="form-control" placeholder="0" name="price">
								</div>
							</div>
							<!--/span-->
						</div>
						<!--/row-->
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label class="control-label"><b>Путь к картинке</b></label>
									<input type="text" class="form-control" name="image" placeholder="Путь к картинке: /style/coin-100.svg" value="">
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label class="control-label"><b>Цвет</b></label>
									<input type="text" class="form-control" placeholder="Цвет спиннера" name="color" value="">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label class="control-label"><b>Диапазон</b></label>
									<input type="text" class="form-control" placeholder="10" name="diapasone" value="">
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label class="control-label"><b>Максимальное число оборотов</b></label>
									<input type="text" class="form-control" placeholder="Максимальное число оборотов" name="max_spin" value="">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label class="control-label"><b>Максимальный профит</b></label>
									<input type="text" class="form-control" placeholder="Максимальный выйгрыш" name="max_profit" value="">
								</div>
							</div>
						</div>
						<div class="row" style="margin-top: 10px;
												margin-bottom: 10px;">
							<div class="col-md-12">
								<div class="form-group">
									<label class="col-md-12 control-label text-center"><b>Шанс окупаемости</b></label>
									<div class="col-md-12">
										<input id="range_1" type="text" name="chance" value=""/>
									</div>
								</div>
							</div>
						</div>
					</div>
					
					<div class="form-actions right">
						<button type="submit" class="btn blue"><i class="fa fa-check"></i> Создать </button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>