-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Авг 24 2017 г., 08:07
-- Версия сервера: 5.5.55-0ubuntu0.14.04.1
-- Версия PHP: 5.5.9-1ubuntu4.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `egger`
--

-- --------------------------------------------------------

--
-- Структура таблицы `drops`
--

CREATE TABLE IF NOT EXISTS `drops` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spinner_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `win` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Дамп данных таблицы `drops`
--

INSERT INTO `drops` (`id`, `spinner_id`, `user_id`, `win`, `created_at`, `updated_at`) VALUES
(1, 3, 5, 26, '2017-08-24 10:14:05', '0000-00-00 00:00:00'),
(2, 3, 5, 27, '2017-08-24 10:14:13', '0000-00-00 00:00:00'),
(3, 3, 5, 3, '2017-08-24 10:14:21', '0000-00-00 00:00:00'),
(4, 4, 5, 40, '2017-08-24 10:14:42', '0000-00-00 00:00:00'),
(5, 4, 5, 47, '2017-08-24 10:14:58', '0000-00-00 00:00:00'),
(6, 4, 5, 372, '2017-08-24 10:15:07', '0000-00-00 00:00:00'),
(7, 4, 5, 372, '2017-08-24 10:15:21', '0000-00-00 00:00:00'),
(8, 4, 5, 32, '2017-08-24 10:15:36', '0000-00-00 00:00:00'),
(9, 5, 5, 85, '2017-08-24 10:15:50', '0000-00-00 00:00:00'),
(10, 5, 5, 684, '2017-08-24 10:16:09', '0000-00-00 00:00:00'),
(11, 4, 5, 372, '2017-08-24 10:16:31', '0000-00-00 00:00:00'),
(12, 7, 5, 164, '2017-08-24 10:16:39', '0000-00-00 00:00:00'),
(13, 7, 5, 192, '2017-08-24 10:17:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Структура таблицы `operations`
--

CREATE TABLE IF NOT EXISTS `operations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `ref` varchar(24) CHARACTER SET utf8 DEFAULT NULL,
  `ref_sum` int(11) DEFAULT NULL,
  `time` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `wallet` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `number` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `operations`
--

INSERT INTO `operations` (`id`, `type`, `amount`, `user`, `ref`, `ref_sum`, `time`, `status`, `wallet`, `number`, `created_at`, `updated_at`) VALUES
(1, 2, 100, 5, NULL, NULL, 1503571655, 0, '45', '123412341234', '2017-08-24 10:47:35', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Структура таблицы `spinners`
--

CREATE TABLE IF NOT EXISTS `spinners` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) CHARACTER SET utf8 NOT NULL,
  `image` varchar(256) CHARACTER SET utf8 NOT NULL,
  `color` varchar(128) CHARACTER SET utf8 NOT NULL,
  `price` int(11) NOT NULL,
  `diapasone` int(11) NOT NULL,
  `max_spin` int(11) NOT NULL,
  `max_profit` int(11) NOT NULL,
  `chance` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Дамп данных таблицы `spinners`
--

INSERT INTO `spinners` (`id`, `name`, `image`, `color`, `price`, `diapasone`, `max_spin`, `max_profit`, `chance`, `created_at`, `updated_at`) VALUES
(1, 'Green Spinner', '/images/spinners/main/green-spinner.png', 'green', 49, 5, 10, 80, 12, '2017-08-24 08:27:13', '2017-08-24 12:27:13'),
(2, 'Yellow Spinner', '/images/spinners/main/yellow-spinner.png', 'yellow', 69, 10, 25, 138, 50, '2017-08-22 05:08:13', '0000-00-00 00:00:00'),
(3, 'Blue Spinner', '/images/spinners/main/blue-spinner.png', 'blue', 99, 20, 50, 209, 50, '2017-08-22 05:08:15', '0000-00-00 00:00:00'),
(4, 'Purple Spinner', '/images/spinners/main/purple-spinner.png', 'purple', 149, 25, 75, 372, 50, '2017-08-22 05:08:17', '0000-00-00 00:00:00'),
(5, 'Dark Spinner', '/images/spinners/main/dark-spinner.png', 'dark', 249, 35, 100, 684, 50, '2017-08-22 05:08:18', '0000-00-00 00:00:00'),
(6, 'Galaxy Spinner', '/images/spinners/main/galaxy-spinner.png', 'galaxy', 399, 50, 125, 1197, 20, '2017-08-22 06:11:48', '0000-00-00 00:00:00'),
(7, 'Colorful Spinner', '/images/spinners/main/color-spinner.png', 'color', 699, 45, 150, 2341, 50, '2017-08-22 05:08:21', '0000-00-00 00:00:00'),
(8, 'Ice Dragon Spinner', '/images/spinners/main/dragon-spinner.png', 'dragon', 999, 50, 175, 5994, 10, '2017-08-22 15:28:08', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(256) NOT NULL,
  `avatar` varchar(256) NOT NULL,
  `login` varchar(256) NOT NULL,
  `money` int(255) NOT NULL,
  `is_admin` int(11) NOT NULL,
  `ref_code` varchar(256) NOT NULL,
  `ref_use` varchar(256) DEFAULT NULL,
  `open_box` int(255) NOT NULL,
  `win` int(255) NOT NULL,
  `remember_token` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '2016-11-08 21:32:40',
  `is_yt` int(11) NOT NULL,
  `login2` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `bonus_time` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '2016-11-08 19:43:23',
  `bonus_time_drop` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT '2016-11-11 18:13:23',
  `free_cases_left` int(11) DEFAULT '0',
  `refferal_money` int(11) NOT NULL DEFAULT '0',
  `ip` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `deposit` int(11) NOT NULL DEFAULT '0',
  `mini_wins` int(11) NOT NULL DEFAULT '0',
  `ban_mini` int(11) NOT NULL DEFAULT '0',
  `profit` int(11) NOT NULL,
  `ban_ticket` int(11) NOT NULL,
  `request` int(11) NOT NULL,
  `profit2` int(11) NOT NULL,
  `timer` int(14) NOT NULL,
  `nick` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `username`, `avatar`, `login`, `money`, `is_admin`, `ref_code`, `ref_use`, `open_box`, `win`, `remember_token`, `created_at`, `updated_at`, `is_yt`, `login2`, `bonus_time`, `bonus_time_drop`, `free_cases_left`, `refferal_money`, `ip`, `deposit`, `mini_wins`, `ban_mini`, `profit`, `ban_ticket`, `request`, `profit2`, `timer`, `nick`) VALUES
(2, 'Smooth George', 'https://pp.userapi.com/c836133/v836133114/4b555/7eYqNZX7UoI.jpg', 'id427728114', 0, 0, 'fYrrBQnZ38YZY', NULL, 0, 0, 'ipHIy3ldTFLnct2Nzy3fKvtBBf1tpF8DUdWFHTp8v8y2flFbGKA07svgV3sh', '2017-08-22 15:58:35', '2017-08-22 19:58:35', 0, '427728114', '2016-11-08 19:43:23', '2016-11-11 18:13:23', 0, 0, '', 0, 0, 0, 0, 0, 0, 0, 0, '8Ee6GB3T'),
(3, 'Петров Виталий', 'https://vk.com/images/camera_200.png', 'id402280844', 695821, 0, '4QGGiRrezeiT3', NULL, 0, 0, 'BnCFo9HNODlKuG5btiKI5HSsQyVXIQcMzTmWfHHcjyXouU0mpW1xzKnTSM1a', '2017-08-24 10:10:19', '2017-08-23 20:49:39', 0, '402280844', '2016-11-08 19:43:23', '2016-11-11 18:13:23', 0, 0, '', 0, 0, 0, 5089, 0, 0, 0, 0, '3AFfGkZr'),
(5, 'Иван Исаев', 'https://pp.userapi.com/c639122/v639122867/2ed74/sp1eLy4IA1Y.jpg', 'id293841867', 729, 1, 'TGB524SH9B38A', '4QGGiRrezeiT3', 0, 0, 'T9hWSl1PduLiaS2kKT0QCP5BT7aWEabSZ6oaUx0ZdZ7Q4r4iQbVTbpNRnmHJ', '2017-08-24 10:47:35', '2017-08-24 14:47:35', 0, '293841867', '2016-11-08 19:43:23', '2016-11-11 18:13:23', 0, 0, '', 0, 0, 0, 2416, 0, 0, 0, 0, '9K3AkNaD');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
